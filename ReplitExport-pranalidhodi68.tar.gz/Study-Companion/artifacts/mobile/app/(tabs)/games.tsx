import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import * as WebBrowser from "expo-web-browser";
import React, { useEffect, useRef, useState } from "react";
import Animated, {
  FadeInDown, FadeInUp,
  useAnimatedStyle, useSharedValue,
  withRepeat, withSequence, withSpring, withTiming,
} from "react-native-reanimated";
import {
  Dimensions, Platform, Pressable, ScrollView,
  StyleSheet, Text, TouchableOpacity, View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

type GameView = "menu" | "chess" | "memory" | "tictactoe" | "mathquiz";

const MUSIC_GENRES = [
  { id: "lofi",      label: "Lo-Fi Beats",    icon: "headphones"   as const, color: "#6366F1", youtubeId: "jfKfPfyJRdk" },
  { id: "classical", label: "Classical Piano", icon: "piano"        as const, color: "#8B5CF6", youtubeId: "XMGrwnkJQJQ" },
  { id: "nature",    label: "Nature Sounds",   icon: "leaf"         as const, color: "#10B981", youtubeId: "eKFTSSKCzWA" },
  { id: "jazz",      label: "Jazz Focus",      icon: "music-note"   as const, color: "#F59E0B", youtubeId: "Dx5qFachd3A" },
  { id: "ambient",   label: "Ambient Study",   icon: "weather-fog"  as const, color: "#3B82F6", youtubeId: "lTRiuFIWV54" },
  { id: "hiphop",    label: "Hip-Hop Chill",   icon: "music"        as const, color: "#EF4444", youtubeId: "5qap5aO4i9A" },
];

const CHESS_UNICODE: Record<string, string> = {
  wK:"♔",wQ:"♕",wR:"♖",wB:"♗",wN:"♘",wP:"♙",
  bK:"♚",bQ:"♛",bR:"♜",bB:"♝",bN:"♞",bP:"♟",
};
const INITIAL_BOARD = (): (string | null)[][] => [
  ["bR","bN","bB","bQ","bK","bB","bN","bR"],["bP","bP","bP","bP","bP","bP","bP","bP"],
  Array(8).fill(null),Array(8).fill(null),Array(8).fill(null),Array(8).fill(null),
  ["wP","wP","wP","wP","wP","wP","wP","wP"],["wR","wN","wB","wQ","wK","wB","wN","wR"],
];
const MEMORY_ICONS = ["star","heart","zap","moon","sun","cloud","droplet","wind"] as const;

// ── Math Quiz Data ──
const MATH_QUESTIONS = [
  { q: "What is 15 × 8?",           opts: ["110","115","120","125"],   ans: 2 },
  { q: "√144 = ?",                  opts: ["11","12","13","14"],       ans: 1 },
  { q: "25% of 200 = ?",            opts: ["40","45","50","55"],       ans: 2 },
  { q: "If 3x = 27, x = ?",         opts: ["6","7","8","9"],           ans: 3 },
  { q: "LCM of 4 and 6?",           opts: ["12","18","24","8"],        ans: 0 },
  { q: "Area of circle r=7 (π=22/7)?",opts:["154","144","164","174"], ans: 0 },
  { q: "1 + 1/2 + 1/4 = ?",         opts: ["1.5","1.75","2","1.25"],  ans: 1 },
  { q: "log₁₀(1000) = ?",           opts: ["2","3","4","10"],         ans: 1 },
  { q: "sin(90°) = ?",              opts: ["0","0.5","1","√2/2"],     ans: 2 },
  { q: "n! when n=5?",              opts: ["60","100","120","24"],     ans: 2 },
];

function GameHeader({ title, onBack, onReset }: { title: string; onBack: () => void; onReset?: () => void }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  return (
    <LinearGradient colors={["#1E2837","#0F172A"]} style={[styles.gameHeader, { paddingTop: topPad + 8 }]}>
      <Pressable onPress={onBack} style={styles.iconBtn}><Feather name="arrow-left" size={20} color={colors.foreground} /></Pressable>
      <Text style={[styles.gameTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>{title}</Text>
      {onReset
        ? <Pressable onPress={onReset} style={styles.iconBtn}><Feather name="refresh-ccw" size={18} color={colors.primary} /></Pressable>
        : <View style={styles.iconBtn} />
      }
    </LinearGradient>
  );
}

// ── Math Quiz Game ──
function MathQuiz({ onBack }: { onBack: () => void }) {
  const colors = useColors();
  const { addCoins, addXP, completeQuest } = useApp();
  const [qIndex, setQIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [done, setDone] = useState(false);
  const [timeLeft, setTimeLeft] = useState(15);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const q = MATH_QUESTIONS[qIndex];

  useEffect(() => {
    if (done) return;
    setTimeLeft(15);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current!);
          handleNext(null);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [qIndex, done]);

  const handleNext = (idx: number | null) => {
    clearInterval(timerRef.current!);
    setSelected(idx);
    const correct = idx === q.ans;
    if (correct) {
      setScore((s) => s + 1);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
    setTimeout(() => {
      if (qIndex + 1 >= MATH_QUESTIONS.length) {
        setDone(true);
        const finalScore = score + (correct ? 1 : 0);
        addCoins(finalScore * 10);
        addXP(finalScore * 15);
        completeQuest("q4");
      } else {
        setQIndex((i) => i + 1);
        setSelected(null);
      }
    }, 900);
  };

  const reset = () => { setQIndex(0); setScore(0); setSelected(null); setDone(false); };

  const timerPct = timeLeft / 15;
  const timerColor = timeLeft > 8 ? "#10B981" : timeLeft > 4 ? "#F59E0B" : "#EF4444";

  return (
    <View style={[{ flex: 1 }, { backgroundColor: colors.background }]}>
      <GameHeader title="Math Quiz" onBack={onBack} onReset={reset} />

      {done ? (
        <Animated.View entering={FadeInUp.springify()} style={[styles.doneCard, { backgroundColor: colors.card, borderColor: colors.primary + "50" }]}>
          <Text style={{ fontSize: 52 }}>{score >= 8 ? "🏆" : score >= 5 ? "⭐" : "📚"}</Text>
          <Text style={[styles.doneTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
            {score >= 8 ? "Excellent!" : score >= 5 ? "Good Job!" : "Keep Practising!"}
          </Text>
          <Text style={[styles.doneScore, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
            {score} / {MATH_QUESTIONS.length} correct
          </Text>
          <Text style={[styles.doneEarned, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            +{score * 10} coins  +{score * 15} XP
          </Text>
          <TouchableOpacity onPress={reset}>
            <LinearGradient colors={["#F59E0B","#F97316"]} style={styles.actionBtn}>
              <Text style={[styles.actionBtnText, { color: "#0F172A", fontFamily: "Inter_700Bold" }]}>Play Again</Text>
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
          {/* Progress */}
          <View style={styles.quizProgress}>
            <Text style={[styles.qNum, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
              {qIndex + 1} / {MATH_QUESTIONS.length}
            </Text>
            <Text style={[styles.scoreLabel, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
              Score: {score}
            </Text>
          </View>
          <View style={[styles.progressBar, { backgroundColor: colors.border }]}>
            <LinearGradient colors={["#F59E0B","#F97316"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={[styles.progressFill, { width: `${((qIndex) / MATH_QUESTIONS.length) * 100}%` as any }]} />
          </View>

          {/* Timer */}
          <View style={styles.timerRow}>
            <Feather name="clock" size={14} color={timerColor} />
            <View style={[styles.timerTrack, { backgroundColor: colors.border }]}>
              <View style={[styles.timerFill, { width: `${timerPct * 100}%` as any, backgroundColor: timerColor }]} />
            </View>
            <Text style={[styles.timerNum, { color: timerColor, fontFamily: "Inter_700Bold" }]}>{timeLeft}s</Text>
          </View>

          {/* Question */}
          <LinearGradient colors={["#1E2837","#1A2435"]} style={[styles.questionCard, { borderColor: colors.border }]}>
            <Text style={[styles.questionText, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
              {q.q}
            </Text>
          </LinearGradient>

          {/* Options */}
          <View style={styles.optionsGrid}>
            {q.opts.map((opt, i) => {
              const isCorrect = i === q.ans;
              const isSelected = selected === i;
              let bgColors: [string, string] = ["#1E2837","#1E2837"];
              let borderColor = colors.border;
              if (selected !== null) {
                if (isCorrect) { bgColors = ["#10B98125","#10B98110"]; borderColor = "#10B981"; }
                else if (isSelected) { bgColors = ["#EF444425","#EF444410"]; borderColor = "#EF4444"; }
              }
              return (
                <Pressable key={i} onPress={() => selected === null && handleNext(i)} style={{ width: "48%" }}>
                  <LinearGradient colors={bgColors} style={[styles.optCard, { borderColor }]}>
                    <View style={[styles.optLabel, { backgroundColor: colors.border }]}>
                      <Text style={[styles.optLabelText, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
                        {["A","B","C","D"][i]}
                      </Text>
                    </View>
                    <Text style={[styles.optText, { color: selected !== null && isCorrect ? "#10B981" : selected !== null && isSelected ? "#EF4444" : colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
                      {opt}
                    </Text>
                  </LinearGradient>
                </Pressable>
              );
            })}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

// ── Chess ──
function ChessGame({ onBack }: { onBack: () => void }) {
  const colors = useColors();
  const [board, setBoard] = useState(INITIAL_BOARD);
  const [selected, setSelected] = useState<[number,number] | null>(null);
  const [turn, setTurn] = useState<"w"|"b">("w");
  const screenW = Dimensions.get("window").width;
  const cellSize = Math.floor((Math.min(screenW, 420) - 32) / 8);

  const handleCell = (row: number, col: number) => {
    Haptics.selectionAsync();
    const piece = board[row][col];
    if (!selected) { if (piece && piece[0] === turn) setSelected([row,col]); return; }
    const [sr,sc] = selected;
    if (sr===row && sc===col) { setSelected(null); return; }
    if (piece && piece[0] === turn) { setSelected([row,col]); return; }
    const nb = board.map((r) => [...r]);
    nb[row][col] = nb[sr][sc]; nb[sr][sc] = null;
    setBoard(nb); setSelected(null); setTurn(turn==="w"?"b":"w");
  };

  return (
    <View style={[{ flex: 1 }, { backgroundColor: colors.background }]}>
      <GameHeader title="Chess" onBack={onBack} onReset={() => { setBoard(INITIAL_BOARD()); setSelected(null); setTurn("w"); }} />
      <ScrollView contentContainerStyle={{ alignItems:"center", paddingTop:20, gap:14 }}>
        <LinearGradient colors={turn==="w"?["#F5F5F520","#0F172A"]:["#1E283730","#0F172A"]} style={styles.turnBadge}>
          <View style={[styles.turnDot, { backgroundColor: turn==="w"?"#F5F5F5":"#334155", borderWidth:1, borderColor:colors.border }]} />
          <Text style={[styles.turnText, { color:colors.foreground, fontFamily:"Inter_600SemiBold" }]}>{turn==="w"?"White":"Black"}'s turn</Text>
        </LinearGradient>
        <View style={[styles.chessBoard, { width:cellSize*8, borderColor:colors.border }]}>
          {board.map((row,ri) => row.map((piece,ci) => {
            const light=(ri+ci)%2===0; const sel=selected?.[0]===ri&&selected?.[1]===ci;
            return (
              <Pressable key={`${ri}-${ci}`} onPress={()=>handleCell(ri,ci)}
                style={[{ width:cellSize, height:cellSize, alignItems:"center", justifyContent:"center" },
                  sel?{backgroundColor:"#F59E0B90"}:{backgroundColor:light?"#E8D5B0":"#8B6542"}]}>
                {piece?<Text style={{ fontSize:cellSize*0.55, lineHeight:cellSize*0.7 }}>{CHESS_UNICODE[piece]}</Text>:null}
              </Pressable>
            );
          }))}
        </View>
        <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>Tap piece → tap destination</Text>
      </ScrollView>
    </View>
  );
}

// ── Memory Match ──
function MemoryGame({ onBack }: { onBack: () => void }) {
  const colors = useColors();
  const { addCoins, addXP, completeQuest } = useApp();
  const makeCards = () => [...MEMORY_ICONS,...MEMORY_ICONS].map((icon,i)=>({id:i,icon,flipped:false,matched:false})).sort(()=>Math.random()-0.5);
  const [cards,setCards] = useState(makeCards);
  const [flipped,setFlipped] = useState<number[]>([]);
  const [moves,setMoves] = useState(0);
  const [won,setWon] = useState(false);

  const flip = (id:number) => {
    const card=cards.find((c)=>c.id===id);
    if (!card||card.flipped||card.matched||flipped.length===2) return;
    Haptics.selectionAsync();
    const nf=[...flipped,id];
    setFlipped(nf);
    setCards((prev)=>prev.map((c)=>c.id===id?{...c,flipped:true}:c));
    if (nf.length===2) {
      setMoves((m)=>m+1);
      const [a,b]=nf.map((fid)=>cards.find((c)=>c.id===fid)!);
      if (a.icon===b.icon) {
        setTimeout(()=>{
          setCards((prev)=>{
            const next=prev.map((c)=>nf.includes(c.id)?{...c,matched:true}:c);
            if (next.every((c)=>c.matched)){setWon(true);addCoins(100);addXP(150);completeQuest("q4");Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);}
            return next;
          }); setFlipped([]);
        },500);
      } else { setTimeout(()=>{setCards((prev)=>prev.map((c)=>nf.includes(c.id)?{...c,flipped:false}:c));setFlipped([]);},900); }
    }
  };
  const reset=()=>{setCards(makeCards());setFlipped([]);setMoves(0);setWon(false);};
  return (
    <View style={[{ flex:1 },{ backgroundColor:colors.background }]}>
      <GameHeader title="Memory Match" onBack={onBack} onReset={reset} />
      <ScrollView contentContainerStyle={{ alignItems:"center", padding:20, gap:16 }}>
        <Text style={[styles.moveText,{ color:colors.mutedForeground, fontFamily:"Inter_500Medium" }]}>{won?"🎉 You Won! ":""}Moves: {moves}</Text>
        <View style={styles.memGrid}>
          {cards.map((card)=>(
            <Pressable key={card.id} onPress={()=>flip(card.id)}>
              <View style={[styles.memCard,{ backgroundColor:card.matched?colors.primary+"25":card.flipped?colors.card:"#1E2837", borderColor:card.matched?colors.primary:card.flipped?colors.border:"#334155" }]}>
                {card.flipped||card.matched
                  ?<Feather name={card.icon as any} size={24} color={card.matched?colors.primary:colors.foreground}/>
                  :<Feather name="help-circle" size={20} color={colors.mutedForeground}/>}
              </View>
            </Pressable>
          ))}
        </View>
        {won&&<TouchableOpacity onPress={reset}><LinearGradient colors={["#F59E0B","#F97316"]} style={styles.actionBtn}><Text style={[styles.actionBtnText,{ color:"#0F172A", fontFamily:"Inter_700Bold" }]}>Play Again</Text></LinearGradient></TouchableOpacity>}
      </ScrollView>
    </View>
  );
}

// ── Tic-Tac-Toe ──
function TicTacToe({ onBack }: { onBack: () => void }) {
  const colors = useColors();
  const { addCoins } = useApp();
  const [board,setBoard] = useState<(string|null)[]>(Array(9).fill(null));
  const [xTurn,setXTurn] = useState(true);
  const [winner,setWinner] = useState<string|null>(null);
  const check=(b:(string|null)[])=>{
    const lines=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for(const[a,b1,c]of lines){if(b[a]&&b[a]===b[b1]&&b[a]===b[c])return b[a];}
    return b.every(Boolean)?"Draw":null;
  };
  const press=(i:number)=>{
    if(board[i]||winner)return;
    Haptics.selectionAsync();
    const nb=[...board];nb[i]=xTurn?"X":"O";
    setBoard(nb);setXTurn(!xTurn);
    const w=check(nb);if(w){setWinner(w);if(w!=="Draw")addCoins(50);Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);}
  };
  const reset=()=>{setBoard(Array(9).fill(null));setXTurn(true);setWinner(null);};
  return (
    <View style={[{ flex:1 },{ backgroundColor:colors.background }]}>
      <GameHeader title="Tic-Tac-Toe" onBack={onBack} onReset={reset} />
      <View style={{ alignItems:"center", padding:24, gap:20 }}>
        <Text style={[styles.statusText,{ color:winner?colors.primary:colors.mutedForeground, fontFamily:"Inter_600SemiBold" }]}>
          {winner?(winner==="Draw"?"It's a Draw! 🤝":`${winner} Wins! 🎉`):`${xTurn?"X":"O"}'s turn`}
        </Text>
        <View style={styles.tttGrid}>
          {board.map((cell,i)=>(
            <Pressable key={i} onPress={()=>press(i)}>
              <LinearGradient
                colors={cell==="X"?["#F59E0B25","#F97316"+"12"]:cell==="O"?["#EF444425","#EF444412"]:["#1E2837","#1E2837"]}
                style={[styles.tttCell,{ borderColor:cell==="X"?"#F59E0B70":cell==="O"?"#EF444470":colors.border }]}>
                <Text style={[styles.tttText,{ color:cell==="X"?"#F59E0B":"#EF4444", fontFamily:"Inter_700Bold" }]}>{cell??""}</Text>
              </LinearGradient>
            </Pressable>
          ))}
        </View>
        {winner&&<TouchableOpacity onPress={reset}><LinearGradient colors={["#F59E0B","#F97316"]} style={styles.actionBtn}><Text style={[styles.actionBtnText,{ color:"#0F172A", fontFamily:"Inter_700Bold" }]}>Play Again</Text></LinearGradient></TouchableOpacity>}
      </View>
    </View>
  );
}

// ── Main Screen ──
export default function GamesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addCoins, completeQuest } = useApp();
  const [gameView, setGameView] = useState<GameView>("menu");
  const [playingId, setPlayingId] = useState<string | null>(null);
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84 + 20 : insets.bottom + 70;

  const playMusic = async (g: typeof MUSIC_GENRES[0]) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setPlayingId(g.id); addCoins(5);
    await WebBrowser.openBrowserAsync(`https://www.youtube.com/watch?v=${g.youtubeId}`);
  };

  const openGame = (id: GameView) => { setGameView(id); completeQuest("q4"); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); };

  if (gameView==="chess")     return <ChessGame    onBack={()=>setGameView("menu")} />;
  if (gameView==="memory")    return <MemoryGame   onBack={()=>setGameView("menu")} />;
  if (gameView==="tictactoe") return <TicTacToe    onBack={()=>setGameView("menu")} />;
  if (gameView==="mathquiz")  return <MathQuiz     onBack={()=>setGameView("menu")} />;

  const GAME_CARDS = [
    { id:"chess"      as GameView, label:"Chess",       icon:"chess-queen"  as const, color:"#F59E0B", desc:"Classic strategy" },
    { id:"memory"     as GameView, label:"Memory Match",icon:"cards"        as const, color:"#3B82F6", desc:"Flip & match pairs" },
    { id:"tictactoe"  as GameView, label:"Tic-Tac-Toe", icon:"pound"        as const, color:"#10B981", desc:"X vs O classic" },
    { id:"mathquiz"   as GameView, label:"Math Quiz",   icon:"calculator"   as const, color:"#EF4444", desc:"10 questions · 15s each" },
  ];

  return (
    <ScrollView style={[{ flex:1 },{ backgroundColor:colors.background }]} contentContainerStyle={{ paddingBottom:botPad }} showsVerticalScrollIndicator={false}>
      <LinearGradient colors={["#1E2837","#0F172A"]} style={[styles.menuHeader,{ paddingTop:topPad+12 }]}>
        <Text style={[styles.menuTitle,{ color:colors.foreground, fontFamily:"Inter_700Bold" }]}>Games & Music</Text>
        <Text style={[styles.menuSub,{ color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>Refresh your mind · Earn coins</Text>
      </LinearGradient>

      {/* Music */}
      <View style={styles.section}>
        <Text style={[styles.sectionLabel,{ color:colors.mutedForeground, fontFamily:"Inter_500Medium" }]}>FOCUS MUSIC</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap:10 }}>
          {MUSIC_GENRES.map((g,i)=>(
            <Animated.View key={g.id} entering={FadeInDown.delay(i*60).springify()}>
              <Pressable onPress={()=>playMusic(g)}>
                <LinearGradient colors={[g.color+"30",g.color+"10"]} style={[styles.musicCard,{ borderColor:playingId===g.id?g.color:g.color+"40", borderWidth:playingId===g.id?2:1 }]}>
                  <View style={[styles.musicIconWrap,{ backgroundColor:g.color+"30" }]}>
                    <MaterialCommunityIcons name={g.icon} size={22} color={g.color}/>
                  </View>
                  <Text style={[styles.musicLabel,{ color:colors.foreground, fontFamily:"Inter_600SemiBold" }]}>{g.label}</Text>
                  <View style={[styles.playRow,{ height:20 }]}>
                    {playingId===g.id?[12,18,14,16].map((h,bi)=><View key={bi} style={[styles.waveBar,{ height:h, backgroundColor:g.color }]}/>):<Feather name="external-link" size={12} color={g.color+"AA"}/>}
                  </View>
                </LinearGradient>
              </Pressable>
            </Animated.View>
          ))}
        </ScrollView>
      </View>

      {/* Games */}
      <View style={styles.section}>
        <Text style={[styles.sectionLabel,{ color:colors.mutedForeground, fontFamily:"Inter_500Medium" }]}>BRAIN GAMES</Text>
        <View style={styles.gamesGrid}>
          {GAME_CARDS.map((game,i)=>(
            <Animated.View key={game.id} entering={FadeInDown.delay(i*80).springify()} style={{ flex:1, minWidth:"44%" }}>
              <Pressable onPress={()=>openGame(game.id)}>
                <LinearGradient colors={[game.color+"22",game.color+"08"]} style={[styles.gameCard,{ borderColor:game.color+"50" }]}>
                  <View style={[styles.gameIconWrap,{ backgroundColor:game.color+"28" }]}>
                    <MaterialCommunityIcons name={game.icon} size={28} color={game.color}/>
                  </View>
                  <Text style={[styles.gameLabel,{ color:colors.foreground, fontFamily:"Inter_700Bold" }]}>{game.label}</Text>
                  <Text style={[styles.gameDesc,{ color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{game.desc}</Text>
                  <LinearGradient colors={[game.color,game.color+"CC"]} style={styles.playBtn}>
                    <Feather name="play" size={12} color="#FFF"/>
                    <Text style={[styles.playBtnText,{ fontFamily:"Inter_600SemiBold" }]}>Play</Text>
                  </LinearGradient>
                </LinearGradient>
              </Pressable>
            </Animated.View>
          ))}

          <Animated.View entering={FadeInDown.delay(320).springify()} style={{ flex:1, minWidth:"44%" }}>
            <Pressable onPress={()=>WebBrowser.openBrowserAsync("https://lichess.org")}>
              <LinearGradient colors={["#8B5CF620","#8B5CF608"]} style={[styles.gameCard,{ borderColor:"#8B5CF650" }]}>
                <View style={[styles.gameIconWrap,{ backgroundColor:"#8B5CF628" }]}>
                  <MaterialCommunityIcons name="chess-bishop" size={28} color="#8B5CF6"/>
                </View>
                <Text style={[styles.gameLabel,{ color:colors.foreground, fontFamily:"Inter_700Bold" }]}>Lichess</Text>
                <Text style={[styles.gameDesc,{ color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>Online chess</Text>
                <LinearGradient colors={["#8B5CF6","#8B5CF6CC"]} style={styles.playBtn}>
                  <Feather name="external-link" size={12} color="#FFF"/>
                  <Text style={[styles.playBtnText,{ fontFamily:"Inter_600SemiBold" }]}>Open</Text>
                </LinearGradient>
              </LinearGradient>
            </Pressable>
          </Animated.View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root:{ flex:1 },
  menuHeader:{ paddingHorizontal:20, paddingBottom:20 },
  menuTitle:{ fontSize:26, letterSpacing:-0.5 },
  menuSub:{ fontSize:13, marginTop:4 },
  section:{ paddingHorizontal:16, paddingTop:20 },
  sectionLabel:{ fontSize:11, letterSpacing:1, marginBottom:12 },
  musicCard:{ width:130, padding:14, borderRadius:18, gap:8 },
  musicIconWrap:{ padding:8, borderRadius:10, alignSelf:"flex-start" },
  musicLabel:{ fontSize:13, lineHeight:18 },
  playRow:{ flexDirection:"row", alignItems:"flex-end", gap:2 },
  waveBar:{ width:4, borderRadius:2 },
  gamesGrid:{ flexDirection:"row", flexWrap:"wrap", gap:10 },
  gameCard:{ borderRadius:18, borderWidth:1.5, padding:16, gap:8, flex:1 },
  gameIconWrap:{ padding:10, borderRadius:14, alignSelf:"flex-start" },
  gameLabel:{ fontSize:15 },
  gameDesc:{ fontSize:12 },
  playBtn:{ flexDirection:"row", alignItems:"center", gap:5, paddingHorizontal:14, paddingVertical:7, borderRadius:16, alignSelf:"flex-start", marginTop:4 },
  playBtnText:{ fontSize:12, color:"#FFF" },
  gameHeader:{ flexDirection:"row", justifyContent:"space-between", alignItems:"center", paddingHorizontal:20, paddingBottom:14 },
  iconBtn:{ padding:8, minWidth:36, alignItems:"center" },
  gameTitle:{ fontSize:18 },
  turnBadge:{ flexDirection:"row", alignItems:"center", gap:10, paddingHorizontal:16, paddingVertical:10, borderRadius:20 },
  turnDot:{ width:16, height:16, borderRadius:8 },
  turnText:{ fontSize:15 },
  chessBoard:{ flexDirection:"row", flexWrap:"wrap", borderWidth:2, borderRadius:4, overflow:"hidden" },
  hint:{ fontSize:12, textAlign:"center", marginTop:4 },
  moveText:{ fontSize:16 },
  memGrid:{ flexDirection:"row", flexWrap:"wrap", gap:8, justifyContent:"center" },
  memCard:{ width:72, height:72, borderRadius:14, borderWidth:2, alignItems:"center", justifyContent:"center" },
  tttGrid:{ flexDirection:"row", flexWrap:"wrap", gap:8 },
  tttCell:{ width:100, height:100, borderRadius:18, borderWidth:2, alignItems:"center", justifyContent:"center" },
  tttText:{ fontSize:36 },
  statusText:{ fontSize:18 },
  actionBtn:{ paddingHorizontal:32, paddingVertical:14, borderRadius:20 },
  actionBtnText:{ fontSize:16 },
  quizProgress:{ flexDirection:"row", justifyContent:"space-between" },
  qNum:{ fontSize:14 },
  scoreLabel:{ fontSize:14 },
  progressBar:{ height:6, borderRadius:3, overflow:"hidden" },
  progressFill:{ height:"100%", borderRadius:3 },
  timerRow:{ flexDirection:"row", alignItems:"center", gap:8 },
  timerTrack:{ flex:1, height:8, borderRadius:4, overflow:"hidden" },
  timerFill:{ height:"100%", borderRadius:4 },
  timerNum:{ fontSize:14, minWidth:30, textAlign:"right" },
  questionCard:{ padding:24, borderRadius:18, borderWidth:1, alignItems:"center" },
  questionText:{ fontSize:20, textAlign:"center", lineHeight:30 },
  optionsGrid:{ flexDirection:"row", flexWrap:"wrap", gap:10 },
  optCard:{ borderRadius:16, borderWidth:1.5, padding:14, alignItems:"center", gap:8 },
  optLabel:{ width:28, height:28, borderRadius:14, alignItems:"center", justifyContent:"center" },
  optLabelText:{ fontSize:13 },
  optText:{ fontSize:16, textAlign:"center" },
  doneCard:{ margin:24, borderRadius:24, borderWidth:1.5, padding:32, alignItems:"center", gap:12 },
  doneTitle:{ fontSize:24 },
  doneScore:{ fontSize:32 },
  doneEarned:{ fontSize:14 },
});
