import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import * as WebBrowser from "expo-web-browser";
import React, { useEffect } from "react";
import Animated, {
  FadeInDown, FadeInUp,
  useAnimatedStyle, useSharedValue,
  withRepeat, withSequence, withSpring, withTiming,
} from "react-native-reanimated";
import {
  Platform, Pressable, ScrollView, StyleSheet, Text, View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp, Role } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const ROLES: { key: Role; icon: string; color: string; label: string }[] = [
  { key: "Student",       icon: "book-open",  color: "#3B82F6", label: "Student"  },
  { key: "Teacher",       icon: "users",      color: "#10B981", label: "Teacher"  },
  { key: "Office Worker", icon: "briefcase",  color: "#8B5CF6", label: "Office"   },
];

const EXAMS = [
  { name: "JEE Main",  date: new Date("2026-01-22"), color: "#F59E0B", icon: "calculator-variant" },
  { name: "NEET",      date: new Date("2026-05-04"), color: "#EF4444", icon: "dna" },
  { name: "UPSC",      date: new Date("2026-06-12"), color: "#8B5CF6", icon: "bank" },
  { name: "CA Final",  date: new Date("2026-11-01"), color: "#10B981", icon: "finance" },
];

const QUOTES = [
  '"Education is the most powerful weapon which you can use to change the world." — Mandela',
  '"ज्ञान ही शक्ति है। — Knowledge is Power."',
  '"Success is not final, failure is not fatal: it is the courage to continue that counts."',
  '"सफलता तब मिलती है जब आपके सपने आपके बहाने से बड़े हों।"',
];

const today = new Date();
const quote = QUOTES[today.getDay() % QUOTES.length];

function daysLeft(date: Date) {
  return Math.max(0, Math.ceil((date.getTime() - Date.now()) / 86400000));
}

function StatCard({ icon, label, value, color, delay }: { icon: string; label: string; value: string; color: string; delay: number }) {
  const colors = useColors();
  return (
    <Animated.View entering={FadeInDown.delay(delay).springify()} style={{ flex: 1, minWidth: "44%" }}>
      <LinearGradient colors={[color + "22", color + "0A"]} style={[styles.statCard, { borderColor: color + "50" }]}>
        <View style={[styles.statIconWrap, { backgroundColor: color + "30" }]}>
          <Feather name={icon as any} size={18} color={color} />
        </View>
        <Text style={[styles.statValue, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>{value}</Text>
        <Text style={[styles.statLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{label}</Text>
      </LinearGradient>
    </Animated.View>
  );
}

function FireStreak({ streak }: { streak: number }) {
  const pulse = useSharedValue(1);
  useEffect(() => {
    pulse.value = withRepeat(
      withSequence(withTiming(1.1, { duration: 700 }), withTiming(1, { duration: 700 })),
      -1, false
    );
  }, []);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));
  return (
    <Animated.View style={style}>
      <LinearGradient colors={["#F97316", "#F59E0B"]} style={styles.streakBadge}>
        <Feather name="zap" size={14} color="#FFF" />
        <Text style={[styles.streakNum, { fontFamily: "Inter_700Bold" }]}>{streak}</Text>
        <Text style={[styles.streakLbl, { fontFamily: "Inter_400Regular" }]}>day streak</Text>
      </LinearGradient>
    </Animated.View>
  );
}

function QuestRow({ quest, onComplete }: { quest: { id: string; title: string; reward: number; completed: boolean }; onComplete: (id: string) => void }) {
  const colors = useColors();
  const scale = useSharedValue(1);
  const scaleStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const press = () => {
    if (quest.completed) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    scale.value = withSequence(withSpring(0.95), withSpring(1));
    onComplete(quest.id);
  };
  return (
    <Animated.View style={scaleStyle}>
      <Pressable onPress={press} style={[styles.questCard, {
        backgroundColor: quest.completed ? colors.card + "60" : colors.card,
        borderColor: quest.completed ? colors.primary + "50" : colors.border,
        opacity: quest.completed ? 0.65 : 1,
      }]}>
        <View style={[styles.questCheck, {
          backgroundColor: quest.completed ? colors.primary : "transparent",
          borderColor: quest.completed ? colors.primary : colors.mutedForeground + "70",
        }]}>
          {quest.completed && <Feather name="check" size={10} color="#0F172A" />}
        </View>
        <Text style={[styles.questTitle, { color: quest.completed ? colors.mutedForeground : colors.foreground, fontFamily: "Inter_500Medium", textDecorationLine: quest.completed ? "line-through" : "none" }]} numberOfLines={1}>
          {quest.title}
        </Text>
        <LinearGradient colors={["#F59E0B30", "#F97316" + "15"]} style={styles.rewardPill}>
          <Feather name="star" size={10} color="#F59E0B" />
          <Text style={[styles.rewardTxt, { color: "#F59E0B", fontFamily: "Inter_700Bold" }]}>{quest.reward}</Text>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { role, setRole, coins, streak, xp, level, questsCompleted, studyHoursToday, quests, completeQuest } = useApp();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84 + 20 : insets.bottom + 70;
  const levelProgress = (xp % 500) / 500;
  const currentRole = ROLES.find((r) => r.key === role)!;

  return (
    <ScrollView style={[{ flex: 1 }, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingBottom: botPad }} showsVerticalScrollIndicator={false}>

      {/* ── Header ── */}
      <LinearGradient colors={["#0F172A", "#1A2540", "#0F172A"]} style={[styles.header, { paddingTop: topPad + 12 }]}>
        <Animated.View entering={FadeInUp.duration(500)} style={styles.headerTop}>
          <View>
            <Text style={[styles.appName, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>TwindMind AI</Text>
            <Text style={[styles.appSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>India's Smart Study Companion</Text>
          </View>
          <LinearGradient colors={["#F59E0B", "#F97316"]} style={styles.levelBadge}>
            <Text style={[styles.levelTxt, { color: "#0F172A", fontFamily: "Inter_700Bold" }]}>Lv {level}</Text>
          </LinearGradient>
        </Animated.View>

        <View style={styles.streakRow}>
          <FireStreak streak={streak} />
          <LinearGradient colors={["#F59E0B25", "#F59E0B08"]} style={styles.coinsBadge}>
            <Feather name="star" size={13} color="#F59E0B" />
            <Text style={[styles.coinsNum, { color: "#F59E0B", fontFamily: "Inter_700Bold" }]}>{coins.toLocaleString("en-IN")}</Text>
            <Text style={[styles.coinsLbl, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>coins</Text>
          </LinearGradient>
        </View>

        <View style={styles.xpContainer}>
          <View style={[styles.xpTrack, { backgroundColor: colors.border }]}>
            <LinearGradient colors={["#F59E0B", "#F97316"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={[styles.xpFill, { width: `${Math.round(levelProgress * 100)}%` as any }]} />
          </View>
          <Text style={[styles.xpTxt, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            {xp % 500} / 500 XP to Level {level + 1}
          </Text>
        </View>
      </LinearGradient>

      {/* ── Daily Quote ── */}
      <View style={styles.section}>
        <LinearGradient colors={["#F59E0B12", "#F97316" + "06"]} style={[styles.quoteCard, { borderColor: colors.primary + "30" }]}>
          <Feather name="message-circle" size={14} color={colors.primary} />
          <Text style={[styles.quoteTxt, { color: colors.foreground, fontFamily: "Inter_400Regular" }]}>{quote}</Text>
        </LinearGradient>
      </View>

      {/* ── Role Selector ── */}
      <View style={styles.section}>
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>YOUR ROLE</Text>
        <View style={styles.roleRow}>
          {ROLES.map((r) => (
            <Pressable key={r.key} onPress={() => { Haptics.selectionAsync(); setRole(r.key); }} style={[styles.roleBtn, { backgroundColor: role === r.key ? r.color + "22" : colors.card, borderColor: role === r.key ? r.color : colors.border }]}>
              <View style={[styles.roleIcon, { backgroundColor: r.color + (role === r.key ? "35" : "18") }]}>
                <Feather name={r.icon as any} size={14} color={r.color} />
              </View>
              <Text style={[styles.roleLbl, { color: role === r.key ? r.color : colors.mutedForeground, fontFamily: role === r.key ? "Inter_600SemiBold" : "Inter_400Regular" }]} numberOfLines={1}>{r.label}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* ── Today's Stats ── */}
      <View style={styles.section}>
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>TODAY</Text>
        <View style={styles.statsGrid}>
          <StatCard icon="clock"        label="Study Time" value={`${studyHoursToday}h`}     color="#3B82F6" delay={0}   />
          <StatCard icon="check-circle" label="Quests"     value={`${questsCompleted}`}      color="#10B981" delay={80}  />
          <StatCard icon="trending-up"  label="XP Total"   value={xp.toLocaleString("en-IN")} color="#8B5CF6" delay={160} />
          <StatCard icon="award"        label="Rank"        value="#4"                        color="#F97316" delay={240} />
        </View>
      </View>

      {/* ── Exam Countdown ── */}
      {role === "Student" && (
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>EXAM COUNTDOWN</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
            {EXAMS.map((exam) => {
              const days = daysLeft(exam.date);
              return (
                <Animated.View key={exam.name} entering={FadeInDown.springify()}>
                  <LinearGradient colors={[exam.color + "25", exam.color + "0A"]} style={[styles.examCard, { borderColor: exam.color + "50" }]}>
                    <MaterialCommunityIcons name={exam.icon as any} size={22} color={exam.color} />
                    <Text style={[styles.examName, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>{exam.name}</Text>
                    <Text style={[styles.examDays, { color: exam.color, fontFamily: "Inter_700Bold" }]}>{days}</Text>
                    <Text style={[styles.examDaysLbl, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>days left</Text>
                  </LinearGradient>
                </Animated.View>
              );
            })}
          </ScrollView>
        </View>
      )}

      {/* ── Quick Access ── */}
      <View style={styles.section}>
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>QUICK ACCESS</Text>
        <View style={styles.quickGrid}>
          {[
            { label: "NCERT Books",    icon: "book-open-variant", color: "#3B82F6", url: "https://ncert.nic.in/textbook.php" },
            { label: "JEE Practice",   icon: "calculator",        color: "#F59E0B", url: "https://jeemain.nta.nic.in" },
            { label: "NEET Prep",      icon: "dna",               color: "#EF4444", url: "https://neet.nta.nic.in" },
            { label: "UPSC Portal",    icon: "bank",              color: "#8B5CF6", url: "https://upsc.gov.in" },
          ].map((item, i) => (
            <Animated.View key={item.label} entering={FadeInDown.delay(i * 60).springify()} style={{ flex: 1, minWidth: "44%" }}>
              <Pressable onPress={() => WebBrowser.openBrowserAsync(item.url)}>
                <LinearGradient colors={[item.color + "20", item.color + "08"]} style={[styles.quickCard, { borderColor: item.color + "40" }]}>
                  <MaterialCommunityIcons name={item.icon as any} size={26} color={item.color} />
                  <Text style={[styles.quickLabel, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>{item.label}</Text>
                  <Feather name="external-link" size={11} color={item.color + "AA"} />
                </LinearGradient>
              </Pressable>
            </Animated.View>
          ))}
        </View>
      </View>

      {/* ── Daily Quests ── */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>DAILY QUESTS</Text>
          <LinearGradient colors={["#F59E0B30", "#F97316" + "15"]} style={styles.questCount}>
            <Text style={[styles.questCountTxt, { color: "#F59E0B", fontFamily: "Inter_700Bold" }]}>
              {quests.filter((q) => q.completed).length}/{quests.length}
            </Text>
          </LinearGradient>
        </View>
        {quests.map((q, i) => (
          <Animated.View key={q.id} entering={FadeInDown.delay(i * 50).springify()}>
            <QuestRow quest={q} onComplete={completeQuest} />
          </Animated.View>
        ))}
      </View>

      {/* ── Teacher Class View ── */}
      {role === "Teacher" && (
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>CLASS PERFORMANCE</Text>
          <View style={[styles.classCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {[
              { name: "Aarav Sharma",  weak: "Physics Ch.3",   pct: 68, color: "#EF4444" },
              { name: "Priya Patel",   weak: "Mathematics",    pct: 82, color: "#F59E0B" },
              { name: "Rahul Gupta",   weak: "Chemistry",      pct: 91, color: "#10B981" },
              { name: "Sneha Mishra",  weak: "Biology Ch.7",   pct: 74, color: "#F97316" },
            ].map((s, i) => (
              <View key={i} style={[styles.studentRow, i > 0 && { borderTopWidth: 1, borderTopColor: colors.border }]}>
                <LinearGradient colors={[s.color + "40", s.color + "15"]} style={styles.studentAvatar}>
                  <Text style={[styles.studentInit, { color: s.color, fontFamily: "Inter_700Bold" }]}>{s.name[0]}</Text>
                </LinearGradient>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.studentName, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>{s.name}</Text>
                  <Text style={[styles.studentWeak, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>Weak: {s.weak}</Text>
                  <View style={[styles.mastBar, { backgroundColor: colors.border }]}>
                    <LinearGradient colors={[s.color, s.color + "BB"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={[styles.mastFill, { width: `${s.pct}%` as any }]} />
                  </View>
                </View>
                <Text style={[styles.mastPct, { color: s.color, fontFamily: "Inter_700Bold" }]}>{s.pct}%</Text>
              </View>
            ))}
          </View>
        </View>
      )}

      {/* ── Office Productivity ── */}
      {role === "Office Worker" && (
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>PRODUCTIVITY</Text>
          <View style={styles.statsGrid}>
            <StatCard icon="file-text"  label="Docs Created"  value="12" color="#6366F1" delay={0}  />
            <StatCard icon="users"      label="Meetings"       value="4"  color="#EC4899" delay={80} />
            <StatCard icon="activity"   label="Tasks Done"     value="87%" color="#14B8A6" delay={160} />
            <StatCard icon="briefcase"  label="Projects"       value="3"  color="#F97316" delay={240} />
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingBottom: 20 },
  headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 },
  appName: { fontSize: 26, letterSpacing: -0.5 },
  appSub: { fontSize: 12, marginTop: 3 },
  levelBadge: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20 },
  levelTxt: { fontSize: 13 },
  streakRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 16 },
  streakBadge: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  streakNum: { fontSize: 16, color: "#FFF" },
  streakLbl: { fontSize: 12, color: "#FFF" },
  coinsBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16 },
  coinsNum: { fontSize: 15 },
  coinsLbl: { fontSize: 11 },
  xpContainer: { gap: 6 },
  xpTrack: { height: 6, borderRadius: 3, overflow: "hidden" },
  xpFill: { height: "100%", borderRadius: 3 },
  xpTxt: { fontSize: 11 },
  section: { paddingHorizontal: 16, paddingTop: 18 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  sectionLabel: { fontSize: 11, letterSpacing: 1, marginBottom: 10 },
  quoteCard: { flexDirection: "row", alignItems: "flex-start", gap: 10, padding: 14, borderRadius: 14, borderWidth: 1.5 },
  quoteTxt: { flex: 1, fontSize: 13, lineHeight: 20, fontStyle: "italic" },
  roleRow: { flexDirection: "row", gap: 8 },
  roleBtn: { flex: 1, flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 10, borderRadius: 14, borderWidth: 1.5, gap: 6 },
  roleIcon: { padding: 6, borderRadius: 8 },
  roleLbl: { fontSize: 12, flex: 1 },
  statsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  statCard: { padding: 16, borderRadius: 16, borderWidth: 1, gap: 8 },
  statIconWrap: { padding: 7, borderRadius: 10, alignSelf: "flex-start" },
  statValue: { fontSize: 22 },
  statLabel: { fontSize: 12 },
  examCard: { width: 120, padding: 14, borderRadius: 18, borderWidth: 1.5, alignItems: "center", gap: 4 },
  examName: { fontSize: 13, textAlign: "center" },
  examDays: { fontSize: 26 },
  examDaysLbl: { fontSize: 11 },
  quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  quickCard: { borderRadius: 16, borderWidth: 1.5, padding: 16, alignItems: "center", gap: 8, flex: 1 },
  quickLabel: { fontSize: 13, textAlign: "center" },
  questCount: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  questCountTxt: { fontSize: 13 },
  questCard: { flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 14, borderWidth: 1.5, gap: 10, marginBottom: 8 },
  questCheck: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, alignItems: "center", justifyContent: "center" },
  questTitle: { flex: 1, fontSize: 14 },
  rewardPill: { flexDirection: "row", alignItems: "center", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10, gap: 3 },
  rewardTxt: { fontSize: 12 },
  classCard: { borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  studentRow: { flexDirection: "row", alignItems: "center", padding: 14, gap: 12 },
  studentAvatar: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" },
  studentInit: { fontSize: 16 },
  studentName: { fontSize: 14, marginBottom: 2 },
  studentWeak: { fontSize: 11, marginBottom: 5 },
  mastBar: { height: 4, borderRadius: 2, overflow: "hidden" },
  mastFill: { height: "100%", borderRadius: 2 },
  mastPct: { fontSize: 14, minWidth: 36, textAlign: "right" },
});
