import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useState } from "react";
import Animated, { FadeInDown } from "react-native-reanimated";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const AVATARS = ["🧑‍🎓", "👩‍🏫", "💼", "🧑‍💻", "👨‍🔬", "👩‍🎨", "🦸", "🧙"];

const SUBJECT_OPTIONS = [
  "Mathematics", "Physics", "Chemistry", "Biology", "History",
  "Geography", "English", "Computer Science", "Economics",
  "Psychology", "Accounting", "Business Studies", "Management",
  "Project Management", "Data Analysis", "Machine Learning", "Statistics",
];

const ACHIEVEMENTS = [
  { id: "a1", icon: "fire",       label: "Streak Master",  desc: "14-day streak",   color: "#F59E0B", unlocked: true  },
  { id: "a2", icon: "brain",      label: "AI Scholar",     desc: "100 doubts",      color: "#8B5CF6", unlocked: true  },
  { id: "a3", icon: "trophy",     label: "Quiz Champion",  desc: "Win 10 games",    color: "#F97316", unlocked: false },
  { id: "a4", icon: "book-open",  label: "Bookworm",       desc: "50 papers read",  color: "#3B82F6", unlocked: false },
  { id: "a5", icon: "star",       label: "Top Earner",     desc: "Earn 5000 coins", color: "#10B981", unlocked: false },
  { id: "a6", icon: "award",      label: "Level 10",       desc: "Reach level 10",  color: "#EC4899", unlocked: false },
];

const LEADERBOARD_BASE = [
  { name: "Aarav Sharma",  coins: 2840, streak: 28 },
  { name: "Priya Patel",   coins: 2610, streak: 21 },
  { name: "Zara Khan",     coins: 2400, streak: 19 },
  { name: "Rahul Gupta",   coins: 2200, streak: 15 },
  { name: "You",           coins: 0,    streak: 0,  isMe: true },
];

type ProfileTab = "profile" | "leaderboard" | "achievements" | "settings";

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { coins, streak, xp, level, subjects, setSubjects, resetQuests, questsCompleted, studyHoursToday } = useApp();

  const [activeTab, setActiveTab] = useState<ProfileTab>("profile");
  const [avatarIndex, setAvatarIndex] = useState(0);
  const [name, setName] = useState("You");
  const [notifications, setNotifications] = useState(true);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84 + 20 : insets.bottom + 70;

  const leaderboard = LEADERBOARD_BASE.map((l) => (l.isMe ? { ...l, coins, streak } : l))
    .sort((a, b) => b.coins - a.coins);
  const myRank = leaderboard.findIndex((l) => (l as any).isMe) + 1;

  const toggleSubject = (s: string) => {
    Haptics.selectionAsync();
    if (subjects.includes(s)) { if (subjects.length > 1) setSubjects(subjects.filter((x) => x !== s)); }
    else setSubjects([...subjects, s]);
  };

  const TABS: { id: ProfileTab; label: string; icon: string }[] = [
    { id: "profile",      label: "Profile",      icon: "user" },
    { id: "leaderboard",  label: "Leaderboard",  icon: "award" },
    { id: "achievements", label: "Badges",        icon: "star" },
    { id: "settings",     label: "Settings",     icon: "settings" },
  ];

  return (
    <View style={[{ flex: 1 }, { backgroundColor: colors.background }]}>
      {/* Header */}
      <LinearGradient colors={["#1E2837", "#0F172A"]} style={[styles.header, { paddingTop: topPad + 8 }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>Profile</Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabRow}>
          {TABS.map((t) => (
            <Pressable
              key={t.id}
              onPress={() => setActiveTab(t.id)}
              style={[
                styles.tabChip,
                { backgroundColor: activeTab === t.id ? colors.primary + "25" : "transparent", borderColor: activeTab === t.id ? colors.primary : colors.border },
              ]}
            >
              <Feather name={t.icon as any} size={13} color={activeTab === t.id ? colors.primary : colors.mutedForeground} />
              <Text style={[styles.tabChipText, { color: activeTab === t.id ? colors.primary : colors.mutedForeground, fontFamily: activeTab === t.id ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                {t.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      </LinearGradient>

      {/* PROFILE */}
      {activeTab === "profile" && (
        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: botPad, gap: 14 }} showsVerticalScrollIndicator={false}>
          {/* Avatar Card */}
          <LinearGradient colors={["#1E2837", "#1A2435"]} style={[styles.profileCard, { borderColor: colors.border }]}>
            <LinearGradient colors={["#F59E0B40", "#F97316" + "20"]} style={styles.avatarRing}>
              <Text style={styles.bigAvatar}>{AVATARS[avatarIndex]}</Text>
            </LinearGradient>
            <View style={{ flex: 1 }}>
              <TextInput
                style={[styles.nameInput, { color: colors.foreground, borderBottomColor: colors.border, fontFamily: "Inter_700Bold" }]}
                value={name}
                onChangeText={setName}
                placeholder="Your name"
                placeholderTextColor={colors.mutedForeground}
              />
              <LinearGradient colors={["#F59E0B", "#F97316"]} style={styles.levelPill}>
                <Text style={[styles.levelPillText, { color: "#0F172A", fontFamily: "Inter_700Bold" }]}>Level {level}</Text>
              </LinearGradient>
            </View>
          </LinearGradient>

          {/* Avatar Picker */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {AVATARS.map((av, i) => (
              <Pressable key={i} onPress={() => { setAvatarIndex(i); Haptics.selectionAsync(); }}>
                <LinearGradient
                  colors={i === avatarIndex ? ["#F59E0B30", "#F97316" + "15"] : ["#1E2837", "#1E2837"]}
                  style={[styles.avatarOpt, { borderColor: i === avatarIndex ? colors.primary : colors.border }]}
                >
                  <Text style={{ fontSize: 28 }}>{av}</Text>
                </LinearGradient>
              </Pressable>
            ))}
          </ScrollView>

          {/* Stats */}
          <View style={styles.statsRow}>
            {[
              { label: "Coins",      value: coins.toLocaleString(), icon: "star",        color: "#F59E0B" },
              { label: "Streak",     value: `${streak}d`,           icon: "zap",         color: "#EF4444" },
              { label: "Study",      value: `${studyHoursToday}h`,  icon: "clock",       color: "#3B82F6" },
              { label: "Quests",     value: `${questsCompleted}`,   icon: "check-circle", color: "#10B981" },
            ].map((s) => (
              <LinearGradient key={s.label} colors={[s.color + "20", s.color + "08"]} style={[styles.miniStat, { borderColor: s.color + "40" }]}>
                <Feather name={s.icon as any} size={16} color={s.color} />
                <Text style={[styles.miniStatVal, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>{s.value}</Text>
                <Text style={[styles.miniStatLbl, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{s.label}</Text>
              </LinearGradient>
            ))}
          </View>

          {/* Subjects */}
          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>My Subjects</Text>
            <View style={styles.subjectGrid}>
              {SUBJECT_OPTIONS.map((s) => {
                const active = subjects.includes(s);
                return (
                  <Pressable
                    key={s}
                    onPress={() => toggleSubject(s)}
                    style={[styles.subjectPill, { backgroundColor: active ? colors.primary + "20" : colors.muted, borderColor: active ? colors.primary : "transparent" }]}
                  >
                    {active && <Feather name="check" size={10} color={colors.primary} />}
                    <Text style={[styles.subjectPillText, { color: active ? colors.primary : colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>{s}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          <Pressable onPress={() => { resetQuests(); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); }}>
            <LinearGradient colors={[colors.primary + "20", colors.primary + "10"]} style={[styles.resetBtn, { borderColor: colors.primary + "50" }]}>
              <Feather name="refresh-ccw" size={16} color={colors.primary} />
              <Text style={[styles.resetBtnText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>Reset Daily Quests</Text>
            </LinearGradient>
          </Pressable>
        </ScrollView>
      )}

      {/* LEADERBOARD */}
      {activeTab === "leaderboard" && (
        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: botPad, gap: 10 }} showsVerticalScrollIndicator={false}>
          <LinearGradient colors={["#F59E0B25", "#F97316" + "10"]} style={[styles.rankBanner, { borderColor: colors.primary + "60" }]}>
            <LinearGradient colors={["#F59E0B", "#F97316"]} style={styles.trophyWrap}>
              <MaterialCommunityIcons name="trophy" size={20} color="#0F172A" />
            </LinearGradient>
            <View>
              <Text style={[styles.rankLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>Your Rank</Text>
              <Text style={[styles.rankValue, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
                #{myRank} of {leaderboard.length}
              </Text>
            </View>
          </LinearGradient>

          {leaderboard.map((entry, i) => {
            const isMe = !!(entry as any).isMe;
            const medalColors = ["#F59E0B", "#94A3B8", "#CD7C3E"];
            return (
              <Animated.View key={i} entering={FadeInDown.delay(i * 60).springify()}>
                <LinearGradient
                  colors={isMe ? ["#F59E0B15", "#F97316" + "08"] : [colors.card, colors.card]}
                  style={[styles.leaderRow, { borderColor: isMe ? colors.primary + "50" : colors.border }]}
                >
                  <Text style={[styles.rankNum, { color: i < 3 ? medalColors[i] : colors.mutedForeground, fontFamily: "Inter_700Bold" }]}>
                    #{i + 1}
                  </Text>
                  <LinearGradient
                    colors={isMe ? ["#F59E0B40", "#F97316" + "20"] : [colors.muted, colors.muted]}
                    style={styles.leaderAvatar}
                  >
                    <Text style={[styles.leaderInit, { color: isMe ? colors.primary : colors.mutedForeground, fontFamily: "Inter_700Bold" }]}>
                      {entry.name[0]}
                    </Text>
                  </LinearGradient>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.leaderName, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
                      {entry.name}{isMe ? " (You)" : ""}
                    </Text>
                    <Text style={[styles.leaderStreak, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                      {entry.streak} day streak
                    </Text>
                  </View>
                  <View style={styles.coinsRight}>
                    <Feather name="star" size={13} color="#F59E0B" />
                    <Text style={[styles.leaderCoins, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
                      {entry.coins.toLocaleString()}
                    </Text>
                  </View>
                </LinearGradient>
              </Animated.View>
            );
          })}
        </ScrollView>
      )}

      {/* ACHIEVEMENTS */}
      {activeTab === "achievements" && (
        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: botPad }} showsVerticalScrollIndicator={false}>
          <View style={styles.achievGrid}>
            {ACHIEVEMENTS.map((a, i) => (
              <Animated.View key={a.id} entering={FadeInDown.delay(i * 60).springify()} style={{ flex: 1, minWidth: "44%" }}>
                <LinearGradient
                  colors={a.unlocked ? [a.color + "25", a.color + "10"] : [colors.card, colors.card]}
                  style={[styles.achievCard, { borderColor: a.unlocked ? a.color + "60" : colors.border, opacity: a.unlocked ? 1 : 0.5 }]}
                >
                  <View style={[styles.achievIcon, { backgroundColor: a.color + (a.unlocked ? "30" : "15") }]}>
                    <MaterialCommunityIcons name={a.icon as any} size={28} color={a.unlocked ? a.color : colors.mutedForeground} />
                  </View>
                  <Text style={[styles.achievLabel, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>{a.label}</Text>
                  <Text style={[styles.achievDesc, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{a.desc}</Text>
                  {a.unlocked && (
                    <LinearGradient colors={[a.color, a.color + "CC"]} style={styles.unlockedDot}>
                      <Feather name="check" size={10} color="#FFF" />
                    </LinearGradient>
                  )}
                </LinearGradient>
              </Animated.View>
            ))}
          </View>
        </ScrollView>
      )}

      {/* SETTINGS */}
      {activeTab === "settings" && (
        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: botPad, gap: 10 }} showsVerticalScrollIndicator={false}>
          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>Preferences</Text>
            <View style={styles.settingRow}>
              <Feather name="bell" size={18} color={colors.primary} />
              <Text style={[styles.settingLabel, { color: colors.foreground, fontFamily: "Inter_500Medium" }]}>Notifications</Text>
              <Switch value={notifications} onValueChange={setNotifications} trackColor={{ false: colors.muted, true: colors.primary + "80" }} thumbColor={notifications ? colors.primary : colors.mutedForeground} />
            </View>
          </View>

          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>About</Text>
            {[
              { label: "App Version",  value: "1.0.0" },
              { label: "Build Date",   value: "2026.06.03" },
              { label: "AI Engine",    value: "TwindMind AI" },
              { label: "Total XP",     value: xp.toLocaleString() },
            ].map((item, i) => (
              <View key={item.label} style={[styles.aboutRow, i > 0 && { borderTopWidth: 1, borderTopColor: colors.border }]}>
                <Text style={[styles.aboutLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{item.label}</Text>
                <Text style={[styles.aboutValue, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>{item.value}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 16, paddingBottom: 12 },
  headerTitle: { fontSize: 22, marginBottom: 12 },
  tabRow: { gap: 8, paddingRight: 4 },
  tabChip: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, borderWidth: 1.5, marginRight: 4 },
  tabChipText: { fontSize: 13 },
  profileCard: { flexDirection: "row", alignItems: "center", borderRadius: 18, borderWidth: 1, padding: 16, gap: 14 },
  avatarRing: { width: 68, height: 68, borderRadius: 34, alignItems: "center", justifyContent: "center" },
  bigAvatar: { fontSize: 38 },
  nameInput: { fontSize: 20, borderBottomWidth: 1, paddingBottom: 4, marginBottom: 8 },
  levelPill: { alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 14 },
  levelPillText: { fontSize: 12 },
  avatarOpt: { borderRadius: 14, borderWidth: 2, padding: 6 },
  statsRow: { flexDirection: "row", gap: 8 },
  miniStat: { flex: 1, alignItems: "center", padding: 12, borderRadius: 14, borderWidth: 1, gap: 4 },
  miniStatVal: { fontSize: 18 },
  miniStatLbl: { fontSize: 11 },
  section: { borderRadius: 16, borderWidth: 1, padding: 16 },
  sectionTitle: { fontSize: 15, marginBottom: 12 },
  subjectGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  subjectPill: { flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1.5, gap: 4 },
  subjectPillText: { fontSize: 12 },
  resetBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderWidth: 1.5, borderRadius: 14, padding: 14, gap: 8 },
  resetBtnText: { fontSize: 15 },
  rankBanner: { flexDirection: "row", alignItems: "center", borderRadius: 16, borderWidth: 1.5, padding: 16, gap: 14, marginBottom: 4 },
  trophyWrap: { padding: 10, borderRadius: 14 },
  rankLabel: { fontSize: 12 },
  rankValue: { fontSize: 24 },
  leaderRow: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1.5, padding: 14, gap: 12 },
  rankNum: { fontSize: 15, minWidth: 30 },
  leaderAvatar: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  leaderInit: { fontSize: 16 },
  leaderName: { fontSize: 15, marginBottom: 2 },
  leaderStreak: { fontSize: 12 },
  coinsRight: { flexDirection: "row", alignItems: "center", gap: 4 },
  leaderCoins: { fontSize: 16 },
  achievGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  achievCard: { borderRadius: 18, borderWidth: 1.5, padding: 14, alignItems: "center", gap: 6, position: "relative" },
  achievIcon: { padding: 12, borderRadius: 14 },
  achievLabel: { fontSize: 13, textAlign: "center" },
  achievDesc: { fontSize: 11, textAlign: "center" },
  unlockedDot: { position: "absolute", top: 8, right: 8, width: 20, height: 20, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  settingRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingTop: 8 },
  settingLabel: { flex: 1, fontSize: 15 },
  aboutRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 10 },
  aboutLabel: { fontSize: 14 },
  aboutValue: { fontSize: 14 },
});
