import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import * as WebBrowser from "expo-web-browser";
import React, { useState } from "react";
import Animated, {
  FadeInDown, useAnimatedStyle, useSharedValue, withTiming, withSpring,
} from "react-native-reanimated";
import {
  Dimensions, Platform, Pressable, ScrollView, StyleSheet, Text, View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

type LearnTab = "ncert" | "videos" | "papers" | "competitive" | "flashcards";

// ─── Data ─────────────────────────────────────────────────────────────────────
const FLASHCARD_DECKS: Record<string, { q: string; a: string; color: string }[]> = {
  Mathematics: [
    { q: "What is the Quadratic Formula?", a: "x = (−b ± √(b²−4ac)) / 2a\nwhere ax² + bx + c = 0", color: "#3B82F6" },
    { q: "What is the sum of first n natural numbers?", a: "Sₙ = n(n+1)/2\n\nExample: 1+2+...+10 = 55", color: "#3B82F6" },
    { q: "Define a prime number.", a: "A number divisible only by 1 and itself.\nExamples: 2, 3, 5, 7, 11, 13, 17, 19, 23...\n\nNote: 1 is NOT a prime number!", color: "#3B82F6" },
    { q: "What is Pythagoras Theorem?", a: "In a right triangle:\na² + b² = c²\nwhere c is the hypotenuse (longest side).", color: "#3B82F6" },
    { q: "What is sin(30°)?", a: "sin(30°) = 1/2\n\nKey values:\nsin(0°)=0, sin(30°)=½, sin(45°)=√2/2\nsin(60°)=√3/2, sin(90°)=1", color: "#3B82F6" },
  ],
  Physics: [
    { q: "State Newton's Second Law of Motion", a: "F = ma\n(Force = mass × acceleration)\n\nSI unit of Force: Newton (N)\n1 N = 1 kg·m/s²", color: "#8B5CF6" },
    { q: "What is Ohm's Law?", a: "V = IR\n(Voltage = Current × Resistance)\n\nV in Volts, I in Amperes, R in Ohms (Ω)", color: "#8B5CF6" },
    { q: "Define escape velocity of Earth.", a: "vₑ = √(2gR) ≈ 11.2 km/s\n\nIt's the minimum speed needed for an object to escape Earth's gravitational pull.", color: "#8B5CF6" },
    { q: "What is the photoelectric effect?", a: "Emission of electrons from a metal surface when light of sufficient frequency falls on it.\n\nKey: Discovered by Hertz, explained by Einstein (Nobel Prize 1921).", color: "#8B5CF6" },
    { q: "State Kepler's Third Law.", a: "T² ∝ a³\n(Square of orbital period ∝ cube of semi-major axis)\n\nThis means planets farther from the Sun take longer to orbit.", color: "#8B5CF6" },
  ],
  Chemistry: [
    { q: "What is Avogadro's Number?", a: "Nₐ = 6.022 × 10²³ mol⁻¹\n\nThis is the number of particles (atoms/molecules) in 1 mole of any substance.", color: "#10B981" },
    { q: "Define electronegativity. Most electronegative element?", a: "Electronegativity: tendency of an atom to attract electrons in a bond.\n\nMost electronegative: Fluorine (F) = 3.98 on Pauling scale.", color: "#10B981" },
    { q: "What is Le Chatelier's Principle?", a: "If a system at equilibrium is disturbed, it shifts to counteract the disturbance.\n\nExample: Increasing pressure → equilibrium shifts to side with fewer moles of gas.", color: "#10B981" },
    { q: "What is the valency of Carbon?", a: "Valency of Carbon = 4\n\nCarbon can form 4 covalent bonds, allowing it to form millions of organic compounds (basis of life).", color: "#10B981" },
  ],
  Biology: [
    { q: "What is the powerhouse of the cell?", a: "Mitochondria 🔋\n\nThey produce ATP (adenosine triphosphate) through cellular respiration.\nBoth plant and animal cells have mitochondria.", color: "#EF4444" },
    { q: "Define osmosis.", a: "Osmosis: movement of water molecules from a region of low solute concentration to high solute concentration through a semi-permeable membrane.\n\nKey: Only water moves, not solute!", color: "#EF4444" },
    { q: "What is the central dogma of molecular biology?", a: "DNA → RNA → Protein\n\nDNA is transcribed to mRNA, which is translated into proteins by ribosomes.", color: "#EF4444" },
    { q: "Name the 4 chambers of the human heart.", a: "Right Atrium → Right Ventricle → Left Atrium → Left Ventricle\n\nBlood flow: Body → Right side → Lungs → Left side → Body", color: "#EF4444" },
  ],
  History: [
    { q: "When was the Indian Constitution enacted?", a: "Adopted: 26 November 1949\nEnacted: 26 January 1950 (Republic Day)\n\nFramed by the Constituent Assembly chaired by Dr. B.R. Ambedkar.", color: "#F59E0B" },
    { q: "What was the Partition of Bengal (1905)?", a: "Lord Curzon divided Bengal into East Bengal (Muslim majority) and West Bengal (Hindu majority).\n\nThis sparked the Swadeshi Movement — boycott of British goods.", color: "#F59E0B" },
    { q: "What is the Preamble of India?", a: "India is a Sovereign, Socialist, Secular, Democratic Republic.\n\n'Socialist' and 'Secular' were added by the 42nd Amendment (1976).", color: "#F59E0B" },
  ],
  "Computer Science": [
    { q: "What is the time complexity of Binary Search?", a: "O(log n)\n\nBinary search halves the search space at each step. Works only on sorted arrays.", color: "#6366F1" },
    { q: "What does HTTP stand for?", a: "Hyper Text Transfer Protocol\n\nHTTPS = HTTP + Secure (uses TLS/SSL encryption).\nDefault port: HTTP=80, HTTPS=443.", color: "#6366F1" },
    { q: "What is a stack data structure?", a: "LIFO — Last In, First Out\n\nOperations: push (add), pop (remove), peek (top element)\nUses: Function calls, undo operations, expression evaluation.", color: "#6366F1" },
    { q: "What is JavaScript?", a: "A high-level, interpreted programming language.\n\nUsed for: Web (frontend), Mobile (React Native), Backend (Node.js).\n\nThis app is built with JavaScript! 🚀", color: "#6366F1" },
  ],
};

const VIDEOS = [
  { title:"NCERT Class 12 Mathematics Complete", channel:"Vedantu", duration:"8h 20m", url:"https://youtube.com/watch?v=OmJ-4B-mS-Y", role:["Student"], color:"#3B82F6", category:"Math" },
  { title:"JEE Physics Complete Course", channel:"Physics Wallah", duration:"40h", url:"https://youtube.com/watch?v=b1t41Q3xRM8", role:["Student"], color:"#8B5CF6", category:"JEE" },
  { title:"NEET Biology Full Syllabus", channel:"Unacademy", duration:"24h", url:"https://youtube.com/watch?v=OGxgnH8y2NM", role:["Student"], color:"#10B981", category:"NEET" },
  { title:"Python Full Course (Hindi)", channel:"CodeWithHarry", duration:"15h 30m", url:"https://youtube.com/watch?v=mU6anWqZJcc", role:["Student","Office Worker"], color:"#F59E0B", category:"Coding" },
  { title:"UPSC GS Paper 1 Complete", channel:"StudyIQ IAS", duration:"30h", url:"https://youtube.com/watch?v=VqWWgNBBpuQ", role:["Student"], color:"#EF4444", category:"UPSC" },
  { title:"Effective Teaching Strategies", channel:"Edutopia", duration:"1h 20m", url:"https://youtube.com/watch?v=gdV9Thuvn1k", role:["Teacher"], color:"#10B981", category:"Pedagogy" },
  { title:"Excel for Office Professionals", channel:"ExcelJet", duration:"3h 30m", url:"https://youtube.com/watch?v=Vl0H-qTclOg", role:["Office Worker"], color:"#EC4899", category:"Excel" },
  { title:"Machine Learning with Python", channel:"Sentdex", duration:"8h 45m", url:"https://youtube.com/watch?v=OGxgnH8y2NM", role:["Student","Office Worker"], color:"#F97316", category:"AI/ML" },
  { title:"CA Foundation Accounts Complete", channel:"ICAI", duration:"20h", url:"https://youtube.com/watch?v=r-uOLxNrNk8", role:["Student","Office Worker"], color:"#F59E0B", category:"CA" },
  { title:"TED: The Power of Learning", channel:"TED", duration:"18m", url:"https://youtube.com/watch?v=iCvmsMzlF7o", role:["Student","Teacher","Office Worker"], color:"#14B8A6", category:"TED Talk" },
];

const PAPERS = [
  { title:"Attention Is All You Need", authors:"Vaswani et al.", journal:"NeurIPS", year:2017, url:"https://arxiv.org/abs/1706.03762", role:["Student","Office Worker"], color:"#8B5CF6", tag:"AI/ML" },
  { title:"Large Language Models in Education", authors:"Mollick & Mollick", journal:"SSRN", year:2023, url:"https://arxiv.org/abs/2304.03133", role:["Student","Teacher"], color:"#F59E0B", tag:"AI + Edu" },
  { title:"Active Learning Improves Student Outcomes", authors:"Freeman et al.", journal:"PNAS", year:2014, url:"https://arxiv.org/abs/1412.0035", role:["Student","Teacher"], color:"#10B981", tag:"Education" },
  { title:"GPT-4 Technical Report", authors:"OpenAI", journal:"OpenAI Blog", year:2023, url:"https://arxiv.org/abs/2303.08774", role:["Student","Teacher","Office Worker"], color:"#14B8A6", tag:"AI" },
  { title:"Remote Work Productivity 2024", authors:"Bloom et al.", journal:"Stanford Econ", year:2024, url:"https://arxiv.org/abs/2004.09770", role:["Office Worker"], color:"#EC4899", tag:"Productivity" },
];

const NCERT_BOOKS = [
  { title:"Mathematics Part I",  class:"Class 12", subject:"Mathematics", url:"https://ncert.nic.in/textbook.php?lemh1=0-14", color:"#3B82F6" },
  { title:"Mathematics Part II", class:"Class 12", subject:"Mathematics", url:"https://ncert.nic.in/textbook.php?lemh2=0-9",  color:"#3B82F6" },
  { title:"Physics Part I",      class:"Class 12", subject:"Physics",     url:"https://ncert.nic.in/textbook.php?leph1=0-14", color:"#8B5CF6" },
  { title:"Physics Part II",     class:"Class 12", subject:"Physics",     url:"https://ncert.nic.in/textbook.php?leph2=0-9",  color:"#8B5CF6" },
  { title:"Chemistry Part I",    class:"Class 12", subject:"Chemistry",   url:"https://ncert.nic.in/textbook.php?lech1=0-8",  color:"#10B981" },
  { title:"Chemistry Part II",   class:"Class 12", subject:"Chemistry",   url:"https://ncert.nic.in/textbook.php?lech2=0-8",  color:"#10B981" },
  { title:"Biology",             class:"Class 12", subject:"Biology",     url:"https://ncert.nic.in/textbook.php?lebo1=0-16", color:"#EF4444" },
  { title:"Mathematics",         class:"Class 10", subject:"Mathematics", url:"https://ncert.nic.in/textbook.php?jemh1=0-15", color:"#F59E0B" },
  { title:"Science",             class:"Class 10", subject:"Science",     url:"https://ncert.nic.in/textbook.php?jesc1=0-16", color:"#6366F1" },
  { title:"English (Flamingo)",  class:"Class 12", subject:"English",     url:"https://ncert.nic.in/textbook.php?lefl1=0-8",  color:"#EC4899" },
];

const COMPETITIVE = [
  { name:"JEE Main",    desc:"Joint Entrance Examination — Engineering",  icon:"calculator-variant" as const, color:"#F59E0B", url:"https://jeemain.nta.nic.in" },
  { name:"JEE Advanced",desc:"IIT entrance — top 2.5 lakh qualify",       icon:"star-four-points"   as const, color:"#F97316", url:"https://jeeadv.ac.in" },
  { name:"NEET UG",     desc:"Medical entrance — MBBS/BDS",               icon:"dna"                as const, color:"#EF4444", url:"https://neet.nta.nic.in" },
  { name:"UPSC CSE",    desc:"IAS/IPS/IFS Civil Services",                icon:"bank"               as const, color:"#8B5CF6", url:"https://upsc.gov.in" },
  { name:"CLAT",        desc:"Common Law Admission Test",                  icon:"scale-balance"      as const, color:"#3B82F6", url:"https://consortiumofnlus.ac.in" },
  { name:"CA Foundation",desc:"Chartered Accountancy — ICAI",              icon:"finance"            as const, color:"#10B981", url:"https://icai.org" },
  { name:"GATE",        desc:"Graduate Aptitude Test in Engineering",      icon:"engine"             as const, color:"#6366F1", url:"https://gate.iitb.ac.in" },
  { name:"CAT",         desc:"IIM MBA Entrance",                           icon:"briefcase"          as const, color:"#EC4899", url:"https://iimcat.ac.in" },
];

const VIDEO_CATS = ["All","JEE","NEET","UPSC","Math","Coding","AI/ML","CA","TED Talk","Pedagogy"];
const FLASHCARD_SUBJECTS = Object.keys(FLASHCARD_DECKS);

// ─── Flashcard Component ─────────────────────────────────────────────────────
function FlashCard({ card, index, onNext }: { card: { q:string; a:string; color:string }; index:number; onNext: () => void }) {
  const colors = useColors();
  const [flipped, setFlipped] = useState(false);
  const rotateY = useSharedValue(0);
  const { addCoins } = useApp();

  const frontStyle = useAnimatedStyle(() => ({
    transform: [{ rotateY: `${rotateY.value}deg` }],
    backfaceVisibility: "hidden",
  }));
  const backStyle = useAnimatedStyle(() => ({
    transform: [{ rotateY: `${rotateY.value + 180}deg` }],
    backfaceVisibility: "hidden",
    position: "absolute", top: 0, left: 0, right: 0,
  }));

  const flip = () => {
    Haptics.selectionAsync();
    if (!flipped) {
      rotateY.value = withTiming(180, { duration: 400 });
      setFlipped(true);
      addCoins(2);
    } else {
      rotateY.value = withTiming(0, { duration: 400 });
      setFlipped(false);
    }
  };

  const handleNext = () => {
    rotateY.value = withTiming(0, { duration: 200 });
    setFlipped(false);
    setTimeout(onNext, 150);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const screenW = Dimensions.get("window").width;
  const cardW = screenW - 32;

  return (
    <View style={{ alignItems:"center", gap:16 }}>
      <Text style={[styles.cardCounter, { color: colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>
        Card {index + 1}  ·  Tap to {flipped ? "hide answer" : "reveal answer"}
      </Text>
      <Pressable onPress={flip} style={{ width: cardW, height: 240 }}>
        <Animated.View style={[frontStyle, { width: cardW, height: 240 }]}>
          <LinearGradient colors={[card.color+"25", card.color+"08"]} style={[styles.flashFace, { borderColor: card.color+"50", width: cardW, height: 240 }]}>
            <View style={[styles.flashBadge, { backgroundColor: card.color+"25" }]}>
              <Text style={[styles.flashBadgeText, { color: card.color, fontFamily:"Inter_600SemiBold" }]}>Question</Text>
            </View>
            <Text style={[styles.flashQ, { color: colors.foreground, fontFamily:"Inter_700Bold" }]}>{card.q}</Text>
          </LinearGradient>
        </Animated.View>
        <Animated.View style={[backStyle, { width: cardW, height: 240 }]}>
          <LinearGradient colors={[card.color+"35", card.color+"15"]} style={[styles.flashFace, { borderColor: card.color, width: cardW, height: 240 }]}>
            <View style={[styles.flashBadge, { backgroundColor: card.color+"40" }]}>
              <Text style={[styles.flashBadgeText, { color: card.color, fontFamily:"Inter_600SemiBold" }]}>Answer ✓</Text>
            </View>
            <Text style={[styles.flashA, { color: colors.foreground, fontFamily:"Inter_400Regular" }]}>{card.a}</Text>
          </LinearGradient>
        </Animated.View>
      </Pressable>
      <View style={styles.flashBtnRow}>
        <Pressable onPress={handleNext}>
          <LinearGradient colors={[card.color, card.color+"CC"]} style={styles.nextBtn}>
            <Text style={[styles.nextBtnText, { fontFamily:"Inter_700Bold" }]}>Next Card →</Text>
          </LinearGradient>
        </Pressable>
      </View>
    </View>
  );
}

// ─── Main Screen ─────────────────────────────────────────────────────────────
export default function LearnScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { role, addXP, completeQuest } = useApp();
  const [tab, setTab] = useState<LearnTab>("ncert");
  const [catFilter, setCatFilter] = useState("All");
  const [flashSubject, setFlashSubject] = useState("Mathematics");
  const [cardIndex, setCardIndex] = useState(0);
  const [score, setScore] = useState(0);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84+20 : insets.bottom+70;

  const roleColor = role==="Student"?"#3B82F6":role==="Teacher"?"#10B981":"#8B5CF6";
  const roleIcon  = role==="Student"?"book-open":role==="Teacher"?"users":"briefcase";
  const deck = FLASHCARD_DECKS[flashSubject] ?? FLASHCARD_DECKS.Mathematics;

  const handleNext = () => {
    const next = (cardIndex+1) % deck.length;
    setCardIndex(next);
    if (next === 0) { setScore((s)=>s+deck.length); addXP(20); completeQuest("q2"); }
  };

  const roleVideos = VIDEOS.filter((v)=>v.role.includes(role));
  const filteredVideos = catFilter==="All"?roleVideos:roleVideos.filter((v)=>v.category===catFilter);
  const filteredPapers = PAPERS.filter((p)=>p.role.includes(role));

  const TABS: { id:LearnTab; label:string; icon:string }[] = [
    { id:"ncert",        label:"NCERT",       icon:"book-open-variant" },
    { id:"flashcards",   label:"Flashcards",  icon:"cards" },
    { id:"videos",       label:"Videos",      icon:"youtube" },
    { id:"papers",       label:"Papers",      icon:"file-document" },
    { id:"competitive",  label:"Exams",       icon:"trophy" },
  ];

  return (
    <View style={[{ flex:1 }, { backgroundColor:colors.background }]}>
      <LinearGradient colors={["#1E2837","#0F172A"]} style={[styles.header, { paddingTop:topPad+8 }]}>
        <View style={styles.headerTop}>
          <View>
            <Text style={[styles.headerTitle, { color:colors.foreground, fontFamily:"Inter_700Bold" }]}>Learn</Text>
            <Text style={[styles.headerSub, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>India Curriculum · {role}</Text>
          </View>
          <LinearGradient colors={[roleColor+"30",roleColor+"12"]} style={styles.rolePill}>
            <Feather name={roleIcon as any} size={13} color={roleColor} />
            <Text style={[styles.rolePillText, { color:roleColor, fontFamily:"Inter_600SemiBold" }]}>{role}</Text>
          </LinearGradient>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabRow}>
          {TABS.map((t) => (
            <Pressable key={t.id} onPress={() => { setTab(t.id); Haptics.selectionAsync(); }}
              style={[styles.tabPill, { backgroundColor:tab===t.id?colors.primary+"22":"transparent", borderColor:tab===t.id?colors.primary:colors.border }]}>
              <MaterialCommunityIcons name={t.icon as any} size={13} color={tab===t.id?colors.primary:colors.mutedForeground} />
              <Text style={[styles.tabPillText, { color:tab===t.id?colors.primary:colors.mutedForeground, fontFamily:tab===t.id?"Inter_600SemiBold":"Inter_400Regular" }]}>{t.label}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </LinearGradient>

      {/* NCERT */}
      {tab==="ncert" && (
        <ScrollView contentContainerStyle={{ padding:16, paddingBottom:botPad, gap:10 }} showsVerticalScrollIndicator={false}>
          <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>Official NCERT textbooks — tap to open on ncert.nic.in</Text>
          {NCERT_BOOKS.map((book,i) => (
            <Animated.View key={book.url+i} entering={FadeInDown.delay(i*40).springify()}>
              <Pressable onPress={() => { WebBrowser.openBrowserAsync(book.url); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}>
                <LinearGradient colors={[book.color+"15",book.color+"05"]} style={[styles.ncertCard, { borderColor:book.color+"40" }]}>
                  <LinearGradient colors={[book.color+"30",book.color+"15"]} style={styles.ncertIcon}>
                    <MaterialCommunityIcons name="book-open-variant" size={20} color={book.color} />
                  </LinearGradient>
                  <View style={{ flex:1 }}>
                    <Text style={[styles.ncertTitle, { color:colors.foreground, fontFamily:"Inter_600SemiBold" }]}>{book.title}</Text>
                    <View style={styles.ncertMeta}>
                      <View style={[styles.badge, { backgroundColor:book.color+"25" }]}>
                        <Text style={[styles.badgeText, { color:book.color, fontFamily:"Inter_600SemiBold" }]}>{book.class}</Text>
                      </View>
                      <Text style={[styles.ncertSubject, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{book.subject}</Text>
                    </View>
                  </View>
                  <Feather name="download" size={16} color={book.color+"AA"} />
                </LinearGradient>
              </Pressable>
            </Animated.View>
          ))}
        </ScrollView>
      )}

      {/* FLASHCARDS */}
      {tab==="flashcards" && (
        <ScrollView contentContainerStyle={{ paddingBottom:botPad }} showsVerticalScrollIndicator={false}>
          {/* Subject picker */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false}
            style={[styles.filterBar, { borderBottomColor:colors.border }]}
            contentContainerStyle={styles.filterContent}>
            {FLASHCARD_SUBJECTS.map((s) => (
              <Pressable key={s} onPress={() => { setFlashSubject(s); setCardIndex(0); Haptics.selectionAsync(); }}
                style={[styles.filterChip, { backgroundColor:flashSubject===s?colors.primary:colors.card, borderColor:flashSubject===s?colors.primary:colors.border }]}>
                <Text style={[styles.filterText, { color:flashSubject===s?colors.primaryForeground:colors.mutedForeground, fontFamily:"Inter_500Medium" }]}>{s}</Text>
              </Pressable>
            ))}
          </ScrollView>

          <View style={{ padding:16, gap:16 }}>
            {/* Score bar */}
            <View style={styles.scoreRow}>
              <LinearGradient colors={["#F59E0B25","#F59E0B08"]} style={styles.scorePill}>
                <Feather name="star" size={12} color="#F59E0B" />
                <Text style={[styles.scorePillText, { color:"#F59E0B", fontFamily:"Inter_700Bold" }]}>{score} cards reviewed</Text>
              </LinearGradient>
              <Text style={[styles.cardProgress, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>
                {cardIndex+1} / {deck.length}
              </Text>
            </View>

            {/* Progress dots */}
            <View style={styles.progressDots}>
              {deck.map((_,i) => (
                <View key={i} style={[styles.dot2, { backgroundColor: i===cardIndex?colors.primary:i<cardIndex?colors.primary+"60":colors.border }]} />
              ))}
            </View>

            <FlashCard card={deck[cardIndex]} index={cardIndex} onNext={handleNext} />

            <LinearGradient colors={["#1E2837","#1A2435"]} style={[styles.flashTip, { borderColor:colors.border }]}>
              <Feather name="zap" size={13} color={colors.primary} />
              <Text style={[styles.flashTipText, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>
                Tap card to flip · Each flip earns 2 coins · Completing a deck earns 20 XP
              </Text>
            </LinearGradient>
          </View>
        </ScrollView>
      )}

      {/* VIDEOS */}
      {tab==="videos" && (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}
            style={[styles.filterBar, { borderBottomColor:colors.border }]}
            contentContainerStyle={styles.filterContent}>
            {VIDEO_CATS.map((cat) => (
              <Pressable key={cat} onPress={() => { setCatFilter(cat); Haptics.selectionAsync(); }}
                style={[styles.filterChip, { backgroundColor:catFilter===cat?colors.primary:colors.card, borderColor:catFilter===cat?colors.primary:colors.border }]}>
                <Text style={[styles.filterText, { color:catFilter===cat?colors.primaryForeground:colors.mutedForeground, fontFamily:"Inter_500Medium" }]}>{cat}</Text>
              </Pressable>
            ))}
          </ScrollView>
          <ScrollView contentContainerStyle={{ padding:16, paddingBottom:botPad, gap:10 }} showsVerticalScrollIndicator={false}>
            <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{filteredVideos.length} video{filteredVideos.length!==1?"s":""} · tap to open on YouTube</Text>
            {filteredVideos.map((v,i) => (
              <Animated.View key={v.url+i} entering={FadeInDown.delay(i*50).springify()}>
                <Pressable onPress={() => { WebBrowser.openBrowserAsync(v.url); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); completeQuest("q2"); }}>
                  <LinearGradient colors={[v.color+"18",v.color+"06"]} style={[styles.videoCard, { borderColor:v.color+"40" }]}>
                    <LinearGradient colors={[v.color+"35",v.color+"18"]} style={styles.videoThumb}>
                      <MaterialCommunityIcons name="youtube" size={30} color={v.color} />
                      <View style={styles.durBadge}><Text style={[styles.durText, { fontFamily:"Inter_500Medium" }]}>{v.duration}</Text></View>
                    </LinearGradient>
                    <View style={styles.videoInfo}>
                      <View style={styles.videoMeta}>
                        <View style={[styles.badge, { backgroundColor:v.color+"25" }]}><Text style={[styles.badgeText, { color:v.color, fontFamily:"Inter_600SemiBold" }]}>{v.category}</Text></View>
                        <Feather name="external-link" size={12} color={colors.mutedForeground} />
                      </View>
                      <Text style={[styles.videoTitle, { color:colors.foreground, fontFamily:"Inter_600SemiBold" }]} numberOfLines={2}>{v.title}</Text>
                      <Text style={[styles.videoChannel, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{v.channel}</Text>
                    </View>
                  </LinearGradient>
                </Pressable>
              </Animated.View>
            ))}
          </ScrollView>
        </>
      )}

      {/* PAPERS */}
      {tab==="papers" && (
        <ScrollView contentContainerStyle={{ padding:16, paddingBottom:botPad, gap:10 }} showsVerticalScrollIndicator={false}>
          <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{filteredPapers.length} papers · tap to open on arXiv</Text>
          {filteredPapers.map((p,i) => (
            <Animated.View key={p.url+i} entering={FadeInDown.delay(i*50).springify()}>
              <Pressable onPress={() => { WebBrowser.openBrowserAsync(p.url); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); completeQuest("q5"); }}>
                <LinearGradient colors={[p.color+"15",p.color+"05"]} style={[styles.paperCard, { borderColor:p.color+"40" }]}>
                  <LinearGradient colors={[p.color+"30",p.color+"15"]} style={styles.paperIcon}>
                    <Feather name="file-text" size={18} color={p.color} />
                  </LinearGradient>
                  <View style={{ flex:1, gap:4 }}>
                    <View style={styles.paperTagRow}>
                      <View style={[styles.badge, { backgroundColor:p.color+"25" }]}><Text style={[styles.badgeText, { color:p.color, fontFamily:"Inter_600SemiBold" }]}>{p.tag}</Text></View>
                      <Text style={[styles.paperYear, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{p.year}</Text>
                    </View>
                    <Text style={[styles.paperTitle, { color:colors.foreground, fontFamily:"Inter_600SemiBold" }]} numberOfLines={2}>{p.title}</Text>
                    <Text style={[styles.paperMeta, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{p.authors} · {p.journal}</Text>
                  </View>
                  <Feather name="chevron-right" size={16} color={p.color+"90"} />
                </LinearGradient>
              </Pressable>
            </Animated.View>
          ))}
        </ScrollView>
      )}

      {/* COMPETITIVE */}
      {tab==="competitive" && (
        <ScrollView contentContainerStyle={{ padding:16, paddingBottom:botPad, gap:10 }} showsVerticalScrollIndicator={false}>
          <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>India's top competitive exams — tap for official portal</Text>
          {COMPETITIVE.map((exam,i) => (
            <Animated.View key={exam.name} entering={FadeInDown.delay(i*50).springify()}>
              <Pressable onPress={() => { WebBrowser.openBrowserAsync(exam.url); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}>
                <LinearGradient colors={[exam.color+"18",exam.color+"06"]} style={[styles.compCard, { borderColor:exam.color+"40" }]}>
                  <LinearGradient colors={[exam.color+"30",exam.color+"15"]} style={styles.compIcon}>
                    <MaterialCommunityIcons name={exam.icon} size={24} color={exam.color} />
                  </LinearGradient>
                  <View style={{ flex:1 }}>
                    <Text style={[styles.compName, { color:colors.foreground, fontFamily:"Inter_700Bold" }]}>{exam.name}</Text>
                    <Text style={[styles.compDesc, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{exam.desc}</Text>
                  </View>
                  <LinearGradient colors={[exam.color,exam.color+"BB"]} style={styles.visitBtn}>
                    <Text style={[styles.visitBtnText, { fontFamily:"Inter_600SemiBold" }]}>Visit</Text>
                    <Feather name="external-link" size={11} color="#FFF" />
                  </LinearGradient>
                </LinearGradient>
              </Pressable>
            </Animated.View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  header:{ paddingHorizontal:16, paddingBottom:12 },
  headerTop:{ flexDirection:"row", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 },
  headerTitle:{ fontSize:26, letterSpacing:-0.5 },
  headerSub:{ fontSize:12, marginTop:2 },
  rolePill:{ flexDirection:"row", alignItems:"center", gap:5, paddingHorizontal:10, paddingVertical:6, borderRadius:14 },
  rolePillText:{ fontSize:12 },
  tabRow:{ gap:8, paddingBottom:12 },
  tabPill:{ flexDirection:"row", alignItems:"center", gap:5, paddingHorizontal:12, paddingVertical:7, borderRadius:16, borderWidth:1.5 },
  tabPillText:{ fontSize:12 },
  filterBar:{ maxHeight:50, borderBottomWidth:1 },
  filterContent:{ paddingHorizontal:14, paddingVertical:10, gap:8 },
  filterChip:{ paddingHorizontal:12, paddingVertical:5, borderRadius:16, borderWidth:1 },
  filterText:{ fontSize:12 },
  hint:{ fontSize:12, marginBottom:4 },
  ncertCard:{ borderRadius:14, borderWidth:1.5, padding:14, flexDirection:"row", alignItems:"center", gap:12 },
  ncertIcon:{ width:44, height:44, borderRadius:12, alignItems:"center", justifyContent:"center" },
  ncertTitle:{ fontSize:14, marginBottom:6 },
  ncertMeta:{ flexDirection:"row", alignItems:"center", gap:8 },
  ncertSubject:{ fontSize:12 },
  badge:{ paddingHorizontal:7, paddingVertical:2, borderRadius:8 },
  badgeText:{ fontSize:10 },
  videoCard:{ borderRadius:16, borderWidth:1.5, overflow:"hidden", flexDirection:"row" },
  videoThumb:{ width:110, height:84, alignItems:"center", justifyContent:"center" },
  durBadge:{ position:"absolute", bottom:5, right:5, backgroundColor:"#000000AA", paddingHorizontal:5, paddingVertical:2, borderRadius:5 },
  durText:{ fontSize:10, color:"#FFF" },
  videoInfo:{ flex:1, padding:12, gap:5, justifyContent:"center" },
  videoMeta:{ flexDirection:"row", justifyContent:"space-between", alignItems:"center" },
  videoTitle:{ fontSize:13, lineHeight:18 },
  videoChannel:{ fontSize:11 },
  paperCard:{ borderRadius:14, borderWidth:1.5, padding:14, flexDirection:"row", alignItems:"center", gap:12 },
  paperIcon:{ width:44, height:44, borderRadius:12, alignItems:"center", justifyContent:"center" },
  paperTagRow:{ flexDirection:"row", alignItems:"center", gap:8 },
  paperYear:{ fontSize:11 },
  paperTitle:{ fontSize:13, lineHeight:18 },
  paperMeta:{ fontSize:11 },
  compCard:{ borderRadius:16, borderWidth:1.5, padding:14, flexDirection:"row", alignItems:"center", gap:12 },
  compIcon:{ width:52, height:52, borderRadius:14, alignItems:"center", justifyContent:"center" },
  compName:{ fontSize:16, marginBottom:4 },
  compDesc:{ fontSize:12, lineHeight:18 },
  visitBtn:{ flexDirection:"row", alignItems:"center", gap:4, paddingHorizontal:12, paddingVertical:8, borderRadius:12 },
  visitBtnText:{ fontSize:12, color:"#FFF" },
  // Flashcards
  cardCounter:{ fontSize:13 },
  flashFace:{ borderRadius:20, borderWidth:2, padding:24, alignItems:"center", justifyContent:"center", gap:16 },
  flashBadge:{ paddingHorizontal:12, paddingVertical:4, borderRadius:12 },
  flashBadgeText:{ fontSize:11 },
  flashQ:{ fontSize:18, textAlign:"center", lineHeight:26 },
  flashA:{ fontSize:14, textAlign:"center", lineHeight:22 },
  flashBtnRow:{ flexDirection:"row", justifyContent:"center", gap:12 },
  nextBtn:{ paddingHorizontal:28, paddingVertical:14, borderRadius:18 },
  nextBtnText:{ fontSize:15, color:"#FFF" },
  flashTip:{ flexDirection:"row", alignItems:"flex-start", gap:8, padding:14, borderRadius:14, borderWidth:1 },
  flashTipText:{ flex:1, fontSize:12, lineHeight:18 },
  scoreRow:{ flexDirection:"row", justifyContent:"space-between", alignItems:"center" },
  scorePill:{ flexDirection:"row", alignItems:"center", gap:5, paddingHorizontal:10, paddingVertical:6, borderRadius:14 },
  scorePillText:{ fontSize:13 },
  cardProgress:{ fontSize:13 },
  progressDots:{ flexDirection:"row", gap:6, justifyContent:"center" },
  dot2:{ width:8, height:8, borderRadius:4 },
});
