import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import * as WebBrowser from "expo-web-browser";
import React, { useCallback, useEffect, useRef, useState } from "react";
import Animated, {
  FadeIn, FadeInDown, FadeInUp,
  useAnimatedStyle, useSharedValue,
  withRepeat, withSequence, withSpring, withTiming,
} from "react-native-reanimated";
import {
  ActivityIndicator, KeyboardAvoidingView, Platform,
  Pressable, ScrollView, StyleSheet, Text, TextInput,
  TouchableOpacity, View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

type SubTab = "doubt" | "timetable" | "documents" | "focus";

// ─── AI Knowledge Base ───────────────────────────────────────────────────────
const AI_KB: Record<string, string[]> = {
  Mathematics: [
    "**Step-by-step Solution:**\n\n1️⃣ Identify what's given and what's asked\n2️⃣ Choose the right formula/theorem\n3️⃣ Substitute values and simplify\n4️⃣ Verify dimensions/units\n\n📌 **Key Formulae to Remember:**\n• Quadratic: x = (−b ± √(b²−4ac)) / 2a\n• AP Sum: Sₙ = n/2(2a + (n−1)d)\n• Integration by parts: ∫u·dv = u·v − ∫v·du\n\n💡 **JEE Tip:** Always check boundary conditions in definite integrals!",
    "**Calculus Breakdown:**\n\n🔹 **Limits** — Check L'Hôpital's rule for 0/0 or ∞/∞ forms\n🔹 **Derivatives** — Chain rule is your best friend\n🔹 **Integrals** — Memorise standard forms: ∫eˣ, ∫sinx, ∫1/(1+x²)\n\n📐 **NCERT Class 12 Key Topics:**\n• Relations & Functions\n• Matrices & Determinants\n• Vector Algebra\n• 3D Geometry\n\n🏆 JEE Mains has ~6 questions from Calculus — prioritise it!",
  ],
  Physics: [
    "**Physics Problem Approach:**\n\n1️⃣ Draw a neat free-body diagram\n2️⃣ Identify all forces (gravity, normal, friction, tension)\n3️⃣ Apply Newton's laws: ΣF = ma\n4️⃣ Use energy conservation where possible\n\n⚡ **JEE Important Topics:**\n• Kinematics (graphs of motion)\n• Laws of Motion + friction\n• Rotational mechanics (moment of inertia)\n• Electrostatics (Gauss's Law)\n• Modern Physics (photoelectric effect)\n\n💡 **Trick:** In NEET, 45% Physics questions come from Class 12 — focus there first!",
    "**Electromagnetism Made Easy:**\n\n🔋 **Key Laws:**\n• Coulomb's Law: F = kq₁q₂/r²\n• Gauss's Law: ΦE = Q_enc/ε₀\n• Faraday's Law: EMF = −dΦ/dt\n• Ampere's Law: ∮B·dl = μ₀I_enc\n\n🎯 **High-Yield NEET Topics:**\n• Capacitors in series/parallel\n• Moving charges in magnetic field\n• Electromagnetic induction\n• AC circuits (impedance, resonance)\n\n📊 Average: 10–12 marks from this chapter in NEET/JEE every year!",
  ],
  Chemistry: [
    "**Organic Chemistry Strategy:**\n\n🧪 **Reaction Mechanisms to Master:**\n• SN1 vs SN2 (carbocation stability)\n• Markovnikov's Rule for addition\n• Aldol Condensation\n• Grignard Reagent reactions\n\n📝 **Memory Tricks:**\n• OIL RIG — Oxidation Is Loss, Reduction Is Gain\n• LEO the lion says GER — Lose Electrons Oxidised, Gain Electrons Reduced\n\n⭐ **NCERT Highlight:** Practise named reactions daily — they appear DIRECTLY in NEET/JEE every year!",
    "**Physical Chemistry Essentials:**\n\n⚗️ **Thermodynamics:**\n• ΔG = ΔH − TΔS (spontaneity)\n• ΔG < 0 → spontaneous reaction\n\n📈 **Chemical Kinetics:**\n• Rate = k[A]ᵐ[B]ⁿ\n• Half-life t₁/₂ = 0.693/k (first order)\n\n🌡️ **Solutions & Colligative Properties:**\n• ΔTb = iKbm (boiling point elevation)\n• ΔTf = iKfm (freezing point depression)\n\n💡 **JEE Trick:** Mole concept + stoichiometry = 2–3 guaranteed easy marks!",
  ],
  Biology: [
    "**NEET Biology Mastery Plan:**\n\n🧬 **High-Priority Chapters:**\n• Cell Biology (60% of Cell chapter appears in NEET)\n• Genetics & Mendelian Inheritance\n• Reproduction in Organisms\n• Human Physiology (digestion, circulation, excretion)\n• Ecology & Environment\n\n📚 **NCERT is KING for NEET Biology!**\n• 85% of NEET Biology questions come DIRECTLY from NCERT\n• Read each line carefully — even diagrams have questions\n\n🏆 Target: 300+/360 in Biology for a good NEET rank!",
    "**Human Physiology Quick Reference:**\n\n❤️ **Circulation:**\n• Heart: 4 chambers, bicuspid & tricuspid valves\n• SA Node = natural pacemaker (~72 beats/min)\n• Blood pressure: 120/80 mmHg (normal)\n\n🫁 **Respiration:**\n• Tidal volume: 500 mL\n• Vital capacity: 3.5–4.8 L\n• Haemoglobin carries O₂ as oxyhaemoglobin\n\n🧠 **Nervous System:**\n• Neuron structure: dendrites → soma → axon\n• Synapse: chemical communication between neurons\n\n💡 Diagram-based questions = 10–15 marks in NEET!",
  ],
  History: [
    "**UPSC History Framework (INTRO → BODY → CONCLUSION):**\n\n📜 **Ancient India:**\n• Indus Valley Civilisation (3300–1300 BCE)\n• Vedic Period → Mahajanapadas → Mauryan Empire\n• Ashoka's Dhamma: policy of non-violence & welfare\n\n🏰 **Medieval India:**\n• Delhi Sultanate (1206–1526)\n• Mughal Empire: Akbar's Sulh-i-kul (universal peace)\n• Bhakti & Sufi movements\n\n🇮🇳 **Modern India:**\n• 1857 Revolt — First War of Independence\n• Indian National Congress (1885)\n• Gandhi's movements: Non-Cooperation, Civil Disobedience, Quit India\n\n📝 UPSC Tip: Give both pros & cons for every policy!",
    "**Freedom Struggle — Key Events:**\n\n🔥 **Timeline:**\n• 1905 — Partition of Bengal, Swadeshi Movement\n• 1919 — Jallianwala Bagh massacre\n• 1920–22 — Non-Cooperation Movement\n• 1930 — Dandi March (Salt Satyagraha)\n• 1942 — Quit India Movement: 'Do or Die'\n• 1947, Aug 15 — Independence\n\n👤 **Key Personalities:**\n• Bal Gangadhar Tilak: 'Swaraj is my birthright'\n• Lala Lajpat Rai: Punjab Kesari\n• Subhas Chandra Bose: Azad Hind Fauj\n• BR Ambedkar: Father of Indian Constitution\n\n💡 For UPSC: Always link events to their social/economic causes!",
  ],
  "Computer Science": [
    "**Data Structures & Algorithms Guide:**\n\n💻 **Time Complexities to Memorise:**\n• Array access: O(1) | Search: O(n)\n• Binary Search: O(log n)\n• Bubble Sort: O(n²) | Merge Sort: O(n log n)\n• Hash Table lookup: O(1) average\n\n🌳 **Trees & Graphs:**\n• BST: left < root < right\n• BFS uses Queue; DFS uses Stack/Recursion\n• Dijkstra's: Shortest path (no negative weights)\n\n⚡ **Dynamic Programming:**\n• Fibonacci: O(n) with memoisation vs O(2ⁿ) naive\n• Classic problems: Knapsack, LCS, Coin Change\n\n🏆 For placements: Master arrays, DP, and graphs first!",
    "**Web Development Roadmap (JavaScript):**\n\n🌐 **Frontend:**\n• HTML5 → CSS3 → JavaScript ES6+\n• React.js — Component-based UI\n• React Native — Cross-platform mobile apps\n\n🔧 **Backend:**\n• Node.js + Express.js — REST APIs\n• Databases: PostgreSQL (SQL) | MongoDB (NoSQL)\n• Authentication: JWT tokens, bcrypt hashing\n\n☁️ **Cloud & DevOps:**\n• Git & GitHub — Version control\n• Docker — Containerisation\n• AWS/GCP/Azure — Cloud hosting\n\n💡 **JavaScript powers this very app you're using! React Native = 100% JS** 🚀",
  ],
  "Machine Learning": [
    "**Machine Learning Fundamentals:**\n\n🤖 **Types of Learning:**\n• Supervised: labelled data (classification, regression)\n• Unsupervised: unlabelled data (clustering, PCA)\n• Reinforcement: reward-based learning (AlphaGo, ChatGPT)\n\n📊 **Key Algorithms:**\n• Linear Regression: y = mx + c (continuous output)\n• Logistic Regression: sigmoid → binary classification\n• Decision Trees → Random Forests (ensemble)\n• SVM: maximise margin between classes\n• Neural Networks: inspired by human brain\n\n🧠 **Deep Learning Stack:**\n• CNN → Image recognition\n• RNN/LSTM → Sequential data\n• Transformer → NLP (GPT, BERT)\n\n💡 Python + scikit-learn + TensorFlow = job-ready ML!",
  ],
  Economics: [
    "**Economics for CA/UPSC:**\n\n📈 **Macroeconomics:**\n• GDP = C + I + G + (X−M)\n• Inflation: CPI vs WPI\n• RBI tools: Repo rate, CRR, SLR\n• Fiscal Policy: Government spending & taxation\n• Monetary Policy: Money supply control\n\n💹 **Indian Economy Key Data:**\n• GDP growth target: ~7% (FY26)\n• Inflation target: 4% ±2% (RBI mandate)\n• Current Account Deficit (CAD)\n• FDI vs FPI flows\n\n🏦 **Budget Terms:**\n• Revenue Deficit = Revenue Expenditure − Revenue Receipts\n• Fiscal Deficit = Total Expenditure − Total Revenue\n\n📝 UPSC GS3 has 20+ marks from Indian Economy every year!",
  ],
  default: [
    "**Smart Study Strategy for Any Subject:**\n\n📚 **The ACTIVE Method:**\n• **A** — Attempt questions FIRST, then read theory\n• **C** — Connect new concepts to what you already know\n• **T** — Teach it to yourself or a friend\n• **I** — Identify weak areas and revisit them\n• **V** — Visualise with diagrams and mind-maps\n• **E** — Evaluate with past papers\n\n⏰ **Time Management (Indian Competitive Exams):**\n• JEE/NEET: 3 hours → 90 questions → 2 min/question max\n• UPSC: Focus on answer writing, not just reading\n• Revision cycles: 1st (same day), 2nd (1 week), 3rd (1 month)\n\n🏆 Consistency > Intelligence. Study 6–8 hours daily with 25-min Pomodoro sessions!",
    "**Memory Techniques for Faster Learning:**\n\n🧠 **Scientifically Proven Methods:**\n\n1️⃣ **Spaced Repetition** — Review at increasing intervals (today → 3 days → 1 week → 1 month)\n2️⃣ **Feynman Technique** — Explain the concept simply, like teaching a child\n3️⃣ **Mind Mapping** — Draw connections between concepts visually\n4️⃣ **Chunking** — Group information into meaningful clusters (7±2 items)\n5️⃣ **Active Recall** — Quiz yourself without looking at notes\n\n💡 **Mnemonics for Indian Exams:**\n• Physics SI units: 'King Henry Died By Drinking Cold Milk' (kilo, hecto, deca, base, deci, centi, milli)\n• Planets: 'My Very Educated Mother Just Served Us Nachos'\n\n📱 Use TwindMind's Flashcards for spaced repetition — built right into Learn tab!",
  ],
};

function getAIResponse(question: string, subject: string): string {
  const q = question.toLowerCase();
  const pool = AI_KB[subject] ?? AI_KB.default;
  const idx = Math.floor(Math.random() * pool.length);
  return pool[idx];
}

// ─── Streaming Text Hook ──────────────────────────────────────────────────────
function useStreamText(text: string, active: boolean, speed = 6): string {
  const [displayed, setDisplayed] = useState("");
  const posRef = useRef(0);
  useEffect(() => {
    if (!active) { setDisplayed(""); posRef.current = 0; return; }
    posRef.current = 0;
    setDisplayed("");
    const iv = setInterval(() => {
      posRef.current += 2;
      if (posRef.current >= text.length) {
        setDisplayed(text);
        clearInterval(iv);
      } else {
        setDisplayed(text.substring(0, posRef.current));
      }
    }, speed);
    return () => clearInterval(iv);
  }, [text, active]);
  return displayed;
}

// ─── Dot Bounce ──────────────────────────────────────────────────────────────
function DotBounce({ delay }: { delay: number }) {
  const y = useSharedValue(0);
  useEffect(() => {
    const t = setTimeout(() => {
      y.value = withRepeat(
        withSequence(withTiming(-7, { duration: 280 }), withTiming(0, { duration: 280 })),
        -1, false
      );
    }, delay);
    return () => clearTimeout(t);
  }, []);
  const style = useAnimatedStyle(() => ({ transform: [{ translateY: y.value }] }));
  return <Animated.View style={[styles.dot, style]} />;
}

// ─── AI Message Bubble ────────────────────────────────────────────────────────
function AIMsgBubble({ content, isStreaming }: { content: string; isStreaming: boolean }) {
  const colors = useColors();
  const streamed = useStreamText(content, isStreaming);
  const displayed = isStreaming ? streamed : content;

  return (
    <View style={[styles.aiBubble, { backgroundColor: colors.card }]}>
      <View style={styles.aiLabelRow}>
        <LinearGradient colors={["#F59E0B30","#F97316"+"15"]} style={styles.aiChip}>
          <MaterialCommunityIcons name="brain" size={11} color="#F59E0B" />
          <Text style={[styles.aiChipText, { color:"#F59E0B", fontFamily:"Inter_600SemiBold" }]}>TwindMind AI</Text>
        </LinearGradient>
      </View>
      <Text style={[styles.bubbleText, { color: colors.foreground, fontFamily:"Inter_400Regular" }]}>
        {displayed}
        {isStreaming && streamed.length < content.length && (
          <Text style={{ color: colors.primary }}>▍</Text>
        )}
      </Text>
    </View>
  );
}

// ─── Pomodoro Focus Timer ─────────────────────────────────────────────────────
const TIMER_MODES = [
  { label: "Focus",       mins: 25, color: "#EF4444", icon: "brain" as const },
  { label: "Short Break", mins: 5,  color: "#10B981", icon: "coffee" as const },
  { label: "Long Break",  mins: 15, color: "#3B82F6", icon: "battery-charging" as const },
];

function FocusTimer() {
  const colors = useColors();
  const { addCoins, addXP, completeQuest } = useApp();
  const [modeIdx, setModeIdx] = useState(0);
  const [running, setRunning] = useState(false);
  const [seconds, setSeconds] = useState(TIMER_MODES[0].mins * 60);
  const [sessions, setSessions] = useState(0);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mode = TIMER_MODES[modeIdx];
  const pulse = useSharedValue(1);

  useEffect(() => {
    setSeconds(mode.mins * 60);
    setRunning(false);
    clearInterval(tickRef.current!);
  }, [modeIdx]);

  useEffect(() => {
    if (running) {
      pulse.value = withRepeat(
        withSequence(withTiming(1.04, { duration: 900 }), withTiming(1, { duration: 900 })),
        -1, false
      );
      tickRef.current = setInterval(() => {
        setSeconds((s) => {
          if (s <= 1) {
            clearInterval(tickRef.current!);
            setRunning(false);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            if (modeIdx === 0) {
              setSessions((n) => n + 1);
              addCoins(30); addXP(50); completeQuest("q3");
            }
            pulse.value = withTiming(1);
            return 0;
          }
          return s - 1;
        });
      }, 1000);
    } else {
      clearInterval(tickRef.current!);
      pulse.value = withTiming(1);
    }
    return () => clearInterval(tickRef.current!);
  }, [running]);

  const toggle = () => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setRunning((r) => !r); };
  const reset = () => { setRunning(false); setSeconds(mode.mins * 60); };

  const pct = seconds / (mode.mins * 60);
  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");
  const pulseStyle = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));

  return (
    <ScrollView contentContainerStyle={{ padding: 20, alignItems:"center", gap: 20 }}>
      {/* Mode selector */}
      <View style={styles.modeRow}>
        {TIMER_MODES.map((m, i) => (
          <Pressable key={m.label} onPress={() => setModeIdx(i)} style={[styles.modeBtn, { backgroundColor: modeIdx===i ? m.color+"25":"transparent", borderColor: modeIdx===i ? m.color : colors.border }]}>
            <MaterialCommunityIcons name={m.icon} size={14} color={modeIdx===i ? m.color : colors.mutedForeground} />
            <Text style={[styles.modeBtnText, { color: modeIdx===i ? m.color : colors.mutedForeground, fontFamily: modeIdx===i?"Inter_600SemiBold":"Inter_400Regular" }]}>{m.label}</Text>
          </Pressable>
        ))}
      </View>

      {/* Ring */}
      <Animated.View style={[styles.ringWrap, pulseStyle]}>
        <LinearGradient colors={[mode.color+"40", mode.color+"10"]} style={[styles.ringOuter, { borderColor: mode.color+"60" }]}>
          <LinearGradient colors={[mode.color+"25", mode.color+"08"]} style={[styles.ringInner, { borderColor: mode.color+"80" }]}>
            <Text style={[styles.timerDigits, { color: colors.foreground, fontFamily:"Inter_700Bold" }]}>{mm}:{ss}</Text>
            <Text style={[styles.timerMode, { color: mode.color, fontFamily:"Inter_500Medium" }]}>{mode.label}</Text>
          </LinearGradient>
        </LinearGradient>
      </Animated.View>

      {/* Progress bar */}
      <View style={styles.timerBarWrap}>
        <View style={[styles.timerBarTrack, { backgroundColor: colors.border }]}>
          <LinearGradient colors={[mode.color, mode.color+"99"]} start={{ x:0,y:0 }} end={{ x:1,y:0 }}
            style={[styles.timerBarFill, { width: `${pct*100}%` as any }]} />
        </View>
        <Text style={[styles.timerBarLabel, { color: colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>
          {Math.round(pct * 100)}% remaining
        </Text>
      </View>

      {/* Controls */}
      <View style={styles.timerControls}>
        <Pressable onPress={reset} style={[styles.timerCtrlBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="refresh-ccw" size={20} color={colors.mutedForeground} />
        </Pressable>
        <Pressable onPress={toggle}>
          <LinearGradient colors={[mode.color, mode.color+"CC"]} style={styles.timerPlayBtn}>
            <Feather name={running ? "pause" : "play"} size={28} color="#FFF" />
          </LinearGradient>
        </Pressable>
        <Pressable onPress={() => WebBrowser.openBrowserAsync("https://www.youtube.com/watch?v=jfKfPfyJRdk")}
          style={[styles.timerCtrlBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="headphones" size={20} color={colors.mutedForeground} />
        </Pressable>
      </View>

      {/* Stats */}
      <View style={styles.focusStatsRow}>
        {[
          { label: "Sessions Today", value: sessions.toString(), color: mode.color },
          { label: "Coins Earned",   value: `${sessions * 30}`,  color: "#F59E0B" },
          { label: "Focus Time",     value: `${sessions * mode.mins}m`, color: "#8B5CF6" },
        ].map((s) => (
          <LinearGradient key={s.label} colors={[s.color+"20",s.color+"08"]} style={[styles.focusStat, { borderColor: s.color+"40" }]}>
            <Text style={[styles.focusStatVal, { color: s.color, fontFamily:"Inter_700Bold" }]}>{s.value}</Text>
            <Text style={[styles.focusStatLabel, { color: colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{s.label}</Text>
          </LinearGradient>
        ))}
      </View>

      <LinearGradient colors={["#1E2837","#1A2435"]} style={[styles.pomodoroTip, { borderColor: colors.border }]}>
        <Feather name="info" size={13} color={colors.primary} />
        <Text style={[styles.pomodoroTipText, { color: colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>
          Pomodoro Technique: 25 min focus → 5 min break. After 4 sessions, take a 15 min break. Earn 30 coins per session! 🏆
        </Text>
      </LinearGradient>
    </ScrollView>
  );
}

// ─── Timetable / Documents (unchanged logic) ──────────────────────────────────
const SUBJECTS_ALL = ["Mathematics","Physics","Chemistry","Biology","History","Geography","English","Computer Science","Economics","Psychology","Accounting","Business Studies","Management","Project Management","Data Analysis","Machine Learning","Statistics"];
const DOC_TYPES = [
  { id:"ppt",   label:"Presentation", icon:"presentation"  as const, color:"#F97316" },
  { id:"pdf",   label:"PDF Report",   icon:"file-pdf-box"  as const, color:"#EF4444" },
  { id:"word",  label:"Word Doc",     icon:"file-word"     as const, color:"#3B82F6" },
  { id:"notes", label:"Study Notes",  icon:"note-text"     as const, color:"#10B981" },
];
const DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat"];
const SLOT_COLORS = ["#3B82F6","#10B981","#F59E0B","#8B5CF6","#EF4444","#EC4899"];
const SLOT_TIMES  = ["06:00","08:30","10:30","14:00","16:00","19:30"];
const SLOT_DURS   = ["1h 30m","2h","1h","2h 30m","1h 30m","1h"];
function genTimetable(subjects: string[]) {
  const slots: { subject:string; time:string; duration:string; color:string; day:string }[] = [];
  DAYS.forEach((day,di) => subjects.slice(0,3).forEach((s,i) => slots.push({ subject:s, time:SLOT_TIMES[(di+i)%6], duration:SLOT_DURS[i%6], color:SLOT_COLORS[i%6], day })));
  return slots.slice(0,18);
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function AIScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addMessage, messages, clearMessages, subjects, addCoins, addXP, completeQuest, role } = useApp();

  const [subTab, setSubTab] = useState<SubTab>("doubt");
  const [selectedSubject, setSelectedSubject] = useState("Mathematics");
  const [input, setInput] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [streamingId, setStreamingId] = useState<string | null>(null);
  const [timetable, setTimetable] = useState<ReturnType<typeof genTimetable>>([]);
  const [timetableReady, setTimetableReady] = useState(false);
  const [docType, setDocType] = useState("ppt");
  const [docTopic, setDocTopic] = useState("");
  const [docReady, setDocReady] = useState(false);
  const [docContent, setDocContent] = useState("");
  const scrollRef = useRef<ScrollView>(null);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 84 : insets.bottom;

  const sendMessage = () => {
    if (!input.trim() || isThinking) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const question = input.trim();
    setInput("");
    addMessage({ role:"user", content:question });
    setIsThinking(true);
    const thinkTime = 900 + Math.random() * 600;
    setTimeout(() => {
      const resp = getAIResponse(question, selectedSubject);
      const msgId = Date.now().toString();
      addMessage({ role:"assistant", content:resp });
      setStreamingId(msgId);
      setIsThinking(false);
      addCoins(10); addXP(15); completeQuest("q1");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTimeout(() => setStreamingId(null), (resp.length / 2) * 6 + 1000);
    }, thinkTime);
  };

  const SUBTABS: { id:SubTab; label:string; icon:string }[] = [
    { id:"doubt",     label:"Doubt Solver", icon:"message-circle" },
    { id:"timetable", label:"Timetable",    icon:"calendar" },
    { id:"documents", label:"Documents",    icon:"file-plus" },
    { id:"focus",     label:"Focus Timer",  icon:"clock" },
  ];

  return (
    <View style={[styles.root, { backgroundColor:colors.background }]}>
      {/* Header */}
      <LinearGradient colors={["#1E2837","#0F172A"]} style={[styles.header, { paddingTop:topPad+8 }]}>
        <View style={styles.headerRow}>
          <View>
            <Text style={[styles.headerTitle, { color:colors.foreground, fontFamily:"Inter_700Bold" }]}>AI Assistant</Text>
            <Text style={[styles.headerSub, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{selectedSubject} · {role}</Text>
          </View>
          <LinearGradient colors={["#F59E0B30","#F97316"+"20"]} style={styles.brainWrap}>
            <MaterialCommunityIcons name="brain" size={22} color={colors.primary} />
          </LinearGradient>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap:8 }}>
          {SUBTABS.map((t) => (
            <Pressable key={t.id} onPress={() => setSubTab(t.id)}
              style={[styles.subTabBtn, { backgroundColor:subTab===t.id?colors.primary+"22":"transparent", borderColor:subTab===t.id?colors.primary:colors.border }]}>
              <Feather name={t.icon as any} size={13} color={subTab===t.id?colors.primary:colors.mutedForeground} />
              <Text style={[styles.subTabText, { color:subTab===t.id?colors.primary:colors.mutedForeground, fontFamily:subTab===t.id?"Inter_600SemiBold":"Inter_400Regular" }]}>{t.label}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </LinearGradient>

      {/* ── DOUBT SOLVER ── */}
      {subTab === "doubt" && (
        <KeyboardAvoidingView style={{ flex:1 }} behavior={Platform.OS==="ios"?"padding":"height"} keyboardVerticalOffset={Platform.OS==="ios"?0:20}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}
            style={[styles.chipBar, { borderBottomColor:colors.border }]}
            contentContainerStyle={styles.chipContent}>
            {SUBJECTS_ALL.map((s) => (
              <Pressable key={s} onPress={() => setSelectedSubject(s)}
                style={[styles.chip, { backgroundColor:selectedSubject===s?colors.primary:colors.card, borderColor:selectedSubject===s?colors.primary:colors.border }]}>
                <Text style={[styles.chipText, { color:selectedSubject===s?colors.primaryForeground:colors.mutedForeground, fontFamily:"Inter_500Medium" }]}>{s}</Text>
              </Pressable>
            ))}
          </ScrollView>

          <ScrollView ref={scrollRef} style={{ flex:1 }} contentContainerStyle={styles.chatContent}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated:true })}>
            {messages.length === 0 && !isThinking && (
              <View style={styles.emptyChat}>
                <LinearGradient colors={["#F59E0B30","#F97316"+"10"]} style={styles.emptyIcon}>
                  <MaterialCommunityIcons name="brain" size={42} color={colors.primary} />
                </LinearGradient>
                <Text style={[styles.emptyTitle, { color:colors.foreground, fontFamily:"Inter_700Bold" }]}>Ask Anything</Text>
                <Text style={[styles.emptySub, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>
                  JEE · NEET · UPSC · NCERT · CA
                </Text>
                <View style={styles.suggestGrid}>
                  {["Explain Newton's 3rd Law","What is Photosynthesis?","Solve: 3x² + 5x − 2 = 0","Causes of 1857 Revolt"].map((q) => (
                    <Pressable key={q} onPress={() => setInput(q)}
                      style={[styles.suggestChip, { backgroundColor:colors.card, borderColor:colors.border }]}>
                      <Text style={[styles.suggestText, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{q}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            )}

            {messages.map((item, idx) => (
              <Animated.View key={item.id} entering={FadeIn.duration(250)}>
                {item.role === "user" ? (
                  <View style={styles.userBubble}>
                    <Text style={[styles.bubbleText, { color:"#0F172A", fontFamily:"Inter_500Medium" }]}>{item.content}</Text>
                  </View>
                ) : (
                  <AIMsgBubble
                    content={item.content}
                    isStreaming={streamingId !== null && idx === messages.length - 1}
                  />
                )}
              </Animated.View>
            ))}

            {isThinking && (
              <View style={[styles.aiBubble, { backgroundColor:colors.card }]}>
                <View style={styles.dotRow}>
                  <DotBounce delay={0} /><DotBounce delay={160} /><DotBounce delay={320} />
                </View>
              </View>
            )}
          </ScrollView>

          <View style={[styles.inputBar, { backgroundColor:colors.card, borderTopColor:colors.border, paddingBottom:botPad+8 }]}>
            {messages.length > 0 && (
              <Pressable onPress={() => { clearMessages(); setStreamingId(null); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }} style={styles.clearBtn}>
                <Feather name="trash-2" size={18} color={colors.mutedForeground} />
              </Pressable>
            )}
            <TextInput
              style={[styles.textInput, { backgroundColor:colors.background, color:colors.foreground, borderColor:colors.border, fontFamily:"Inter_400Regular" }]}
              placeholder="Ask your doubt… (JEE/NEET/UPSC)"
              placeholderTextColor={colors.mutedForeground}
              value={input} onChangeText={setInput}
              multiline returnKeyType="send" onSubmitEditing={sendMessage} />
            <Pressable onPress={sendMessage} disabled={!input.trim()||isThinking}>
              <LinearGradient colors={input.trim()?["#F59E0B","#F97316"]:[colors.muted,colors.muted]} style={styles.sendBtn}>
                <Feather name="send" size={16} color={input.trim()?"#0F172A":colors.mutedForeground} />
              </LinearGradient>
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      )}

      {/* ── TIMETABLE ── */}
      {subTab === "timetable" && (
        <ScrollView contentContainerStyle={{ padding:16, paddingBottom:botPad+80 }} showsVerticalScrollIndicator={false}>
          <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>Focus subject for timetable</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ maxHeight:48 }} contentContainerStyle={{ gap:8, paddingVertical:8 }}>
            {SUBJECTS_ALL.map((s) => (
              <Pressable key={s} onPress={() => setSelectedSubject(s)}
                style={[styles.chip, { backgroundColor:selectedSubject===s?colors.primary:colors.card, borderColor:selectedSubject===s?colors.primary:colors.border }]}>
                <Text style={[styles.chipText, { color:selectedSubject===s?colors.primaryForeground:colors.mutedForeground, fontFamily:"Inter_500Medium" }]}>{s}</Text>
              </Pressable>
            ))}
          </ScrollView>
          <Pressable onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setIsThinking(true); setTimetableReady(false); setTimeout(()=>{ setTimetable(genTimetable(subjects)); setTimetableReady(true); setIsThinking(false); addCoins(30); addXP(50); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); },1500); }} disabled={isThinking}>
            <LinearGradient colors={["#F59E0B","#F97316"]} style={styles.genBtn}>
              {isThinking ? <ActivityIndicator color="#0F172A" /> : <><MaterialCommunityIcons name="calendar-clock" size={18} color="#0F172A"/><Text style={[styles.genBtnText, { color:"#0F172A", fontFamily:"Inter_700Bold" }]}>Generate AI Timetable</Text></>}
            </LinearGradient>
          </Pressable>
          {timetableReady && DAYS.map((day) => (
            <Animated.View key={day} entering={FadeInDown.springify()} style={{ marginBottom:16 }}>
              <Text style={[styles.dayLabel, { color:colors.primary, fontFamily:"Inter_700Bold" }]}>{day}</Text>
              {timetable.filter((s)=>s.day===day).map((slot,i) => (
                <View key={i} style={[styles.slotCard, { backgroundColor:colors.card, borderLeftColor:slot.color }]}>
                  <View style={[styles.slotDot, { backgroundColor:slot.color }]} />
                  <View style={{ flex:1 }}>
                    <Text style={[styles.slotSubject, { color:colors.foreground, fontFamily:"Inter_600SemiBold" }]}>{slot.subject}</Text>
                    <Text style={[styles.slotTime, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>{slot.time} · {slot.duration}</Text>
                  </View>
                </View>
              ))}
            </Animated.View>
          ))}
        </ScrollView>
      )}

      {/* ── DOCUMENTS ── */}
      {subTab === "documents" && (
        <ScrollView contentContainerStyle={{ padding:16, paddingBottom:botPad+80 }} showsVerticalScrollIndicator={false}>
          <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>Choose document type</Text>
          <View style={styles.docGrid}>
            {DOC_TYPES.map((d) => (
              <Pressable key={d.id} onPress={() => { setDocType(d.id); setDocReady(false); }} style={[styles.docCard, { backgroundColor:docType===d.id?d.color+"20":colors.card, borderColor:docType===d.id?d.color:colors.border }]}>
                <MaterialCommunityIcons name={d.icon} size={28} color={d.color} />
                <Text style={[styles.docCardLabel, { color:colors.foreground, fontFamily:"Inter_600SemiBold" }]}>{d.label}</Text>
              </Pressable>
            ))}
          </View>
          <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular", marginTop:16 }]}>Topic or title</Text>
          <TextInput style={[styles.topicInput, { backgroundColor:colors.card, borderColor:colors.border, color:colors.foreground, fontFamily:"Inter_400Regular" }]} placeholder="e.g. Photosynthesis in Plants" placeholderTextColor={colors.mutedForeground} value={docTopic} onChangeText={(t)=>{ setDocTopic(t); setDocReady(false); }} />
          <Text style={[styles.hint, { color:colors.mutedForeground, fontFamily:"Inter_400Regular" }]}>Subject</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ maxHeight:44 }} contentContainerStyle={{ gap:8, paddingBottom:8 }}>
            {SUBJECTS_ALL.map((s) => (
              <Pressable key={s} onPress={() => setSelectedSubject(s)} style={[styles.chip, { backgroundColor:selectedSubject===s?colors.primary:colors.card, borderColor:selectedSubject===s?colors.primary:colors.border }]}>
                <Text style={[styles.chipText, { color:selectedSubject===s?colors.primaryForeground:colors.mutedForeground, fontFamily:"Inter_500Medium" }]}>{s}</Text>
              </Pressable>
            ))}
          </ScrollView>
          <Pressable onPress={() => { if (!docTopic.trim()) return; Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setIsThinking(true); setDocReady(false); const typeLabel=DOC_TYPES.find((d)=>d.id===docType)?.label??"Document"; setTimeout(()=>{ setDocContent(`AI-Generated ${typeLabel}\n\nTopic: ${docTopic}\nSubject: ${selectedSubject}\n\n━━━ OUTLINE ━━━\n\n1. Introduction\n   • Background & context\n   • Purpose & objectives\n\n2. Core Concepts\n   • Key terminology\n   • Fundamental principles\n\n3. Main Analysis\n   • Detailed explanation with examples\n   • Supporting evidence & data\n\n4. Indian Context\n   • Relevance to NCERT/competitive exams\n   • Real-world applications in India\n\n5. Conclusion\n   • Summary of findings\n   • Exam tips & mnemonics`); setDocReady(true); setIsThinking(false); addCoins(50); addXP(80); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); },2000); }} disabled={!docTopic.trim()||isThinking}>
            <LinearGradient colors={docTopic.trim()?["#F59E0B","#F97316"]:[colors.muted,colors.muted]} style={styles.genBtn}>
              {isThinking?<ActivityIndicator color="#0F172A"/>:<><Feather name="file-plus" size={18} color={docTopic.trim()?"#0F172A":colors.mutedForeground}/><Text style={[styles.genBtnText, { color:docTopic.trim()?"#0F172A":colors.mutedForeground, fontFamily:"Inter_700Bold" }]}>Generate Document</Text></>}
            </LinearGradient>
          </Pressable>
          {docReady && (
            <Animated.View entering={FadeInUp.springify()} style={[styles.docPreview, { backgroundColor:colors.card, borderColor:"#10B981" }]}>
              <View style={{ flexDirection:"row", alignItems:"center", gap:10, marginBottom:12 }}>
                <LinearGradient colors={["#10B98130","#10B98110"]} style={{ padding:6, borderRadius:10 }}>
                  <Feather name="check-circle" size={16} color="#10B981" />
                </LinearGradient>
                <Text style={[styles.docPreviewTitle, { color:"#10B981", fontFamily:"Inter_700Bold" }]}>Document Generated!</Text>
              </View>
              <Text style={[styles.docPreviewContent, { color:colors.foreground, fontFamily:"Inter_400Regular" }]}>{docContent}</Text>
            </Animated.View>
          )}
        </ScrollView>
      )}

      {/* ── FOCUS TIMER ── */}
      {subTab === "focus" && <FocusTimer />}
    </View>
  );
}

const styles = StyleSheet.create({
  root:{ flex:1 },
  header:{ paddingHorizontal:16, paddingBottom:12 },
  headerRow:{ flexDirection:"row", justifyContent:"space-between", alignItems:"center", marginBottom:12 },
  headerTitle:{ fontSize:22 },
  headerSub:{ fontSize:12, marginTop:2 },
  brainWrap:{ padding:10, borderRadius:14 },
  subTabBtn:{ flexDirection:"row", alignItems:"center", paddingHorizontal:12, paddingVertical:8, borderRadius:12, borderWidth:1.5, gap:5 },
  subTabText:{ fontSize:12 },
  chipBar:{ maxHeight:48, borderBottomWidth:1 },
  chipContent:{ paddingHorizontal:12, paddingVertical:8, gap:8 },
  chip:{ paddingHorizontal:12, paddingVertical:6, borderRadius:16, borderWidth:1 },
  chipText:{ fontSize:12 },
  chatContent:{ padding:16, gap:8, flexGrow:1 },
  emptyChat:{ flex:1, alignItems:"center", paddingTop:40, gap:12 },
  emptyIcon:{ padding:22, borderRadius:30, marginBottom:4 },
  emptyTitle:{ fontSize:22 },
  emptySub:{ fontSize:13 },
  suggestGrid:{ flexDirection:"row", flexWrap:"wrap", gap:8, justifyContent:"center", marginTop:8 },
  suggestChip:{ paddingHorizontal:12, paddingVertical:8, borderRadius:12, borderWidth:1 },
  suggestText:{ fontSize:12 },
  userBubble:{ alignSelf:"flex-end", backgroundColor:"#F59E0B", borderRadius:18, borderBottomRightRadius:4, padding:14, maxWidth:"84%" },
  aiBubble:{ alignSelf:"flex-start", borderRadius:18, borderBottomLeftRadius:4, padding:14, maxWidth:"88%", gap:8 },
  aiLabelRow:{ flexDirection:"row" },
  aiChip:{ flexDirection:"row", alignItems:"center", gap:4, paddingHorizontal:8, paddingVertical:3, borderRadius:10 },
  aiChipText:{ fontSize:10 },
  bubbleText:{ fontSize:14, lineHeight:22 },
  dotRow:{ flexDirection:"row", gap:5, alignItems:"center", paddingVertical:4 },
  dot:{ width:7, height:7, borderRadius:4, backgroundColor:"#F59E0B" },
  inputBar:{ flexDirection:"row", alignItems:"flex-end", padding:12, borderTopWidth:1, gap:8 },
  clearBtn:{ padding:8 },
  textInput:{ flex:1, borderWidth:1, borderRadius:20, paddingHorizontal:16, paddingVertical:10, maxHeight:100, fontSize:14 },
  sendBtn:{ width:42, height:42, borderRadius:21, alignItems:"center", justifyContent:"center" },
  hint:{ fontSize:13, marginBottom:10 },
  genBtn:{ flexDirection:"row", alignItems:"center", justifyContent:"center", padding:16, borderRadius:14, gap:8, marginBottom:16 },
  genBtnText:{ fontSize:16 },
  dayLabel:{ fontSize:13, marginBottom:8 },
  slotCard:{ flexDirection:"row", alignItems:"center", borderLeftWidth:4, borderRadius:10, padding:12, marginBottom:8, gap:10 },
  slotDot:{ width:8, height:8, borderRadius:4 },
  slotSubject:{ fontSize:14, marginBottom:2 },
  slotTime:{ fontSize:12 },
  docGrid:{ flexDirection:"row", flexWrap:"wrap", gap:10, marginBottom:16 },
  docCard:{ flex:1, minWidth:"44%", alignItems:"center", padding:16, borderRadius:14, borderWidth:1.5, gap:8 },
  docCardLabel:{ fontSize:13 },
  topicInput:{ borderWidth:1, borderRadius:12, padding:14, fontSize:15, marginBottom:12 },
  docPreview:{ borderRadius:14, borderWidth:1.5, padding:16, marginTop:4 },
  docPreviewTitle:{ fontSize:15 },
  docPreviewContent:{ fontSize:12, lineHeight:20 },
  // Focus Timer
  modeRow:{ flexDirection:"row", gap:8, width:"100%" },
  modeBtn:{ flex:1, flexDirection:"row", alignItems:"center", justifyContent:"center", gap:5, paddingVertical:10, borderRadius:14, borderWidth:1.5 },
  modeBtnText:{ fontSize:12 },
  ringWrap:{ alignItems:"center", justifyContent:"center" },
  ringOuter:{ width:230, height:230, borderRadius:115, alignItems:"center", justifyContent:"center", borderWidth:3 },
  ringInner:{ width:190, height:190, borderRadius:95, alignItems:"center", justifyContent:"center", borderWidth:2, gap:6 },
  timerDigits:{ fontSize:52, letterSpacing:-1 },
  timerMode:{ fontSize:13 },
  timerBarWrap:{ width:"100%", gap:6 },
  timerBarTrack:{ height:8, borderRadius:4, overflow:"hidden", width:"100%" },
  timerBarFill:{ height:"100%", borderRadius:4 },
  timerBarLabel:{ fontSize:12, textAlign:"center" },
  timerControls:{ flexDirection:"row", alignItems:"center", gap:20 },
  timerCtrlBtn:{ width:52, height:52, borderRadius:26, alignItems:"center", justifyContent:"center", borderWidth:1.5 },
  timerPlayBtn:{ width:72, height:72, borderRadius:36, alignItems:"center", justifyContent:"center" },
  focusStatsRow:{ flexDirection:"row", gap:10, width:"100%" },
  focusStat:{ flex:1, alignItems:"center", padding:14, borderRadius:16, borderWidth:1, gap:4 },
  focusStatVal:{ fontSize:22 },
  focusStatLabel:{ fontSize:10, textAlign:"center" },
  pomodoroTip:{ flexDirection:"row", alignItems:"flex-start", gap:8, padding:14, borderRadius:14, borderWidth:1 },
  pomodoroTipText:{ flex:1, fontSize:12, lineHeight:18 },
});
