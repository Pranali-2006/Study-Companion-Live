import { BlurView } from "expo-blur";
import { Tabs } from "expo-router";
import { Feather, Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";

const TAB_ITEMS = [
  { name: "index",   label: "Home",    iconLib: "feather"   as const, icon: "home" },
  { name: "ai",      label: "AI",      iconLib: "material"  as const, icon: "brain" },
  { name: "learn",   label: "Learn",   iconLib: "feather"   as const, icon: "book-open" },
  { name: "games",   label: "Games",   iconLib: "ionicons"  as const, icon: "game-controller-outline" },
  { name: "profile", label: "Profile", iconLib: "feather"   as const, icon: "user" },
];

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === "web";

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        tabBarStyle: {
          position: "absolute",
          backgroundColor: "transparent",
          borderTopWidth: 0,
          elevation: 0,
          shadowOpacity: 0,
          height: isWeb ? 84 : 60 + insets.bottom,
          paddingBottom: isWeb ? 10 : insets.bottom,
        },
        tabBarBackground: () => (
          <BlurView
            intensity={Platform.OS === "ios" ? 90 : 70}
            tint="dark"
            style={[
              StyleSheet.absoluteFill,
              {
                borderTopWidth: 0.5,
                borderTopColor: colors.border,
                backgroundColor: Platform.OS === "android" ? "#0F172AEE" : "transparent",
              },
            ]}
          />
        ),
        tabBarLabelStyle: {
          fontFamily: "Inter_500Medium",
          fontSize: 11,
          marginBottom: Platform.OS === "ios" ? 0 : 4,
        },
      }}
    >
      {TAB_ITEMS.map((t) => (
        <Tabs.Screen
          key={t.name}
          name={t.name}
          options={{
            title: t.label,
            tabBarIcon: ({ color, size }) => {
              if (t.iconLib === "material")
                return <MaterialCommunityIcons name={t.icon as any} size={size} color={color} />;
              if (t.iconLib === "ionicons")
                return <Ionicons name={t.icon as any} size={size} color={color} />;
              return <Feather name={t.icon as any} size={size} color={color} />;
            },
          }}
        />
      ))}
    </Tabs>
  );
}
