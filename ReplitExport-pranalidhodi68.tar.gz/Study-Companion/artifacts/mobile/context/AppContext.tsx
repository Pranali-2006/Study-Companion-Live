import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

export type Role = "Student" | "Teacher" | "Office Worker";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
}

export interface TimetableSlot {
  id: string;
  subject: string;
  startTime: string;
  endTime: string;
  day: string;
  color: string;
}

export interface Quest {
  id: string;
  title: string;
  reward: number;
  completed: boolean;
}

interface AppState {
  role: Role;
  coins: number;
  streak: number;
  xp: number;
  level: number;
  subjects: string[];
  messages: Message[];
  timetable: TimetableSlot[];
  quests: Quest[];
  studyHoursToday: number;
  questsCompleted: number;
}

interface AppContextType extends AppState {
  setRole: (role: Role) => void;
  addCoins: (amount: number) => void;
  addMessage: (msg: Omit<Message, "id" | "timestamp">) => void;
  clearMessages: () => void;
  setSubjects: (subjects: string[]) => void;
  setTimetable: (slots: TimetableSlot[]) => void;
  completeQuest: (id: string) => void;
  resetQuests: () => void;
  addXP: (amount: number) => void;
}

const DEFAULT_QUESTS: Quest[] = [
  { id: "q1", title: "Solve 3 doubts with AI",   reward: 50, completed: false },
  { id: "q2", title: "Watch 2 learning videos",   reward: 30, completed: false },
  { id: "q3", title: "Study for 1 hour",          reward: 40, completed: false },
  { id: "q4", title: "Play a brain game",          reward: 20, completed: false },
  { id: "q5", title: "Review research paper",      reward: 60, completed: false },
];

const DEFAULT_SUBJECTS = ["Mathematics", "Science", "English", "History", "Computer Science"];

const defaultState: AppState = {
  role: "Student",
  coins: 1240,
  streak: 14,
  xp: 3400,
  level: 7,
  subjects: DEFAULT_SUBJECTS,
  messages: [],
  timetable: [],
  quests: DEFAULT_QUESTS,
  studyHoursToday: 2.5,
  questsCompleted: 3,
};

const AppContext = createContext<AppContextType | null>(null);

const PERSIST_KEY = "twindmind_state";

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(defaultState);

  useEffect(() => {
    AsyncStorage.getItem(PERSIST_KEY).then((raw) => {
      if (!raw) return;
      try {
        const saved = JSON.parse(raw);
        setState((prev) => ({ ...prev, ...saved }));
      } catch {}
    });
  }, []);

  const saveState = useCallback((next: AppState) => {
    AsyncStorage.setItem(
      PERSIST_KEY,
      JSON.stringify({
        role: next.role,
        coins: next.coins,
        streak: next.streak,
        xp: next.xp,
        level: next.level,
        subjects: next.subjects,
        timetable: next.timetable,
        quests: next.quests,
        studyHoursToday: next.studyHoursToday,
        questsCompleted: next.questsCompleted,
      })
    );
  }, []);

  const updateState = useCallback(
    (updater: (prev: AppState) => Partial<AppState>) => {
      setState((prev) => {
        const patch = updater(prev);
        const next = { ...prev, ...patch };
        saveState(next);
        return next;
      });
    },
    [saveState]
  );

  const setRole = useCallback(
    (role: Role) => updateState(() => ({ role })),
    [updateState]
  );

  const addCoins = useCallback(
    (amount: number) =>
      updateState((prev) => ({ coins: prev.coins + amount })),
    [updateState]
  );

  const addXP = useCallback(
    (amount: number) =>
      updateState((prev) => {
        const newXP = prev.xp + amount;
        return { xp: newXP, level: Math.floor(newXP / 500) + 1 };
      }),
    [updateState]
  );

  const addMessage = useCallback(
    (msg: Omit<Message, "id" | "timestamp">) => {
      const newMsg: Message = {
        ...msg,
        id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
        timestamp: Date.now(),
      };
      setState((prev) => ({ ...prev, messages: [...prev.messages, newMsg] }));
    },
    []
  );

  const clearMessages = useCallback(
    () => setState((prev) => ({ ...prev, messages: [] })),
    []
  );

  const setSubjects = useCallback(
    (subjects: string[]) => updateState(() => ({ subjects })),
    [updateState]
  );

  const setTimetable = useCallback(
    (timetable: TimetableSlot[]) => updateState(() => ({ timetable })),
    [updateState]
  );

  const completeQuest = useCallback(
    (id: string) =>
      updateState((prev) => {
        const quest = prev.quests.find((q) => q.id === id);
        if (!quest || quest.completed) return {};
        const updatedQuests = prev.quests.map((q) =>
          q.id === id ? { ...q, completed: true } : q
        );
        const newXP = prev.xp + quest.reward;
        return {
          quests: updatedQuests,
          coins: prev.coins + quest.reward,
          questsCompleted: prev.questsCompleted + 1,
          xp: newXP,
          level: Math.floor(newXP / 500) + 1,
        };
      }),
    [updateState]
  );

  const resetQuests = useCallback(
    () => updateState(() => ({ quests: DEFAULT_QUESTS })),
    [updateState]
  );

  return (
    <AppContext.Provider
      value={{
        ...state,
        setRole,
        addCoins,
        addMessage,
        clearMessages,
        setSubjects,
        setTimetable,
        completeQuest,
        resetQuests,
        addXP,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
