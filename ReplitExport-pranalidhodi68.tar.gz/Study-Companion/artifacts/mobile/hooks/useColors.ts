import colors from "@/constants/colors";

/**
 * Always returns the dark palette — TwindMind AI is a dark-first app.
 */
export function useColors() {
  return { ...(colors as any).dark, radius: colors.radius };
}
